# 7. API Testing – GET /bonds/{AL30}
**Autor: Juan Pérez**

### Esquema de respuesta esperado
```json
{
  "shortName": "AL30",
  "name": "...",
  "debtType": "...",
  "links": { ... }
}
```

### Casos de prueba manual
1. **Get bono válido**; Alta; Bono “AL30” existe.  
   - GET /bonds/AL30  
   - ↳ 200 OK + JSON con campos esperados.  
2. **Get bono inexistente**; Media; Ninguna.  
   - GET /bonds/XYZ  
   - ↳ 404 Not Found.  
3. **Método no permitido**; Baja; Ninguna.  
   - POST /bonds/AL30  
   - ↳ 405 Method Not Allowed.  
4. **Sin autenticación**; Alta; Token ausente.  
   - GET sin Authorization  
   - ↳ 401 Unauthorized.  
5. **Validar enlaces**; Media; Bono válido.  
   - Comprobar links.coupons, links.self, etc.  
   - ↳ Cada URL responde 200 OK. 
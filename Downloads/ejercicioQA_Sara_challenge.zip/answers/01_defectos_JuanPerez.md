# 1. Defectos en la consulta de movimientos
**Autor: Juan Pérez**

| FECHA       | DESCRIPCIÓN                | IMPORTE PESOS | IMPORTE DÓLARES |
|-------------|----------------------------|---------------|-----------------|
| 21/11/2011  | Extracción                 | -1000.00      |                 |
| 12/21/2011  | Depósito                   |               | 1000,00         |
| 01/10/2011  | Débito por transferensia   | 500.00        |                 |

**Defectos detectados**  
1. Formato de fecha inconsistente: `21/11/2011` vs `12/21/2011` vs `01/10/2011`.  
2. Separador decimal distinto: punto en pesos vs coma en dólares.  
3. Entidad HTML sin decodificar: “Dep&oacute;sito” debería mostrarse “Depósito”.  
4. Error ortográfico: “transferensia” → “transferencia”.  
5. Campo “Importe Pesos” vacío en el depósito.  
6. Falta de signo claro (+/-) para cada movimiento.

*Se han marcado estos defectos en el documento con círculos alrededor de los valores afectados.*
# 5. Cobertura de Flujos de Decisión
**Autor: Juan Pérez**

Los tests cubren:
- A: A, B, D, E, G  
- B: A, B, D, E, F, G  
- C: A, C, F, C, F, C, F, G  

**Decisión E no ha sido testeada completamente.**  
Falta el flujo E→F sin pasar por E→G.
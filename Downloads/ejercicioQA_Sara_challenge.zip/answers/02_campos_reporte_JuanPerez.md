# 2. Campos para reporte de defecto
**Autor: Juan Pérez**

Los campos esenciales para informar un defecto son:
- ID
- Resumen breve
- Descripción detallada
- Pasos para reproducir
- Resultado esperado
- Resultado actual
- Severidad / Prioridad
- Entorno / Versión
- Adjuntos (screenshots, logs)

## Reporte de defectos encontrados
1. **ID:** D1  
   **Resumen:** Fecha con formato inconsistente  
   **Descripción:** Se usan formatos DD/MM/AAAA y MM/DD/AAAA en la misma tabla.  
   **Pasos:**  
   1. Abrir la consulta de movimientos.  
   2. Observar las fechas de cada registro.  
   **Resultado esperado:** Formato único DD/MM/AAAA.  
   **Resultado actual:** Mezcla de formatos.  
   **Severidad:** Media  
   **Entorno:** Producción  
   **Adjuntos:** Captura 1.

... (continuar reportando los demás defectos de la sección 1)
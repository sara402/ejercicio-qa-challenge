# 4. Particiones para Cálculo de Bonos
**Autor: Juan Pérez**

El bono depende de la antigüedad:
- Negativo (input inválido)  
- 0 años  
- >0 hasta 2 años  
- >2 hasta <5 años  
- 5 a 10 años  
- >10 años  

**Total:** 6 particiones.  
Justificación: Incluye validación de negativos, cero, y rangos indicados.
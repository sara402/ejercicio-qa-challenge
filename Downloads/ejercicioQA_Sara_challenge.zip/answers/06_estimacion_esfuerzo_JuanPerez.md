# 6. Estimación de Esfuerzo
**Autor: Juan Pérez**

Para estimar esfuerzo considero:
- Complejidad del requerimiento  
- Número de casos de prueba  
- Experiencia del equipo y herramientas  
- Necesidad de datos de prueba y entornos  
- Riesgos y prioridades  

Usaría puntos de historia con un buffer del 20%.
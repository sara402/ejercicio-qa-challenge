# 3. Técnicas de Test
**Autor: Juan Pérez**

## Pruebas Funcionales
Verifican que la aplicación cumpla los requisitos funcionales.
**Caso de prueba (Login):**  
- Objetivo: Validar ingreso con credenciales válidas.  
- Pasos:  
  1. Abrir página de login.  
  2. Ingresar usuario y contraseña válidos.  
  3. Click en “Continue”.  
- Resultado esperado: Redirige al dashboard.

## Pruebas No Funcionales
Miden atributos de calidad (rendimiento, usabilidad, seguridad).
**Caso de prueba (Tiempo de carga):**  
- Objetivo: Página carga en <3s.  
- Pasos:  
  1. Cargar la página de login.  
  2. Medir tiempo hasta renderizado.  
- Resultado esperado: <3 segundos.

## Pruebas de Carga y Estrés
Evaluación bajo carga o estrés del sistema.
**Caso de prueba (1000 usuarios concurrentes):**  
- Objetivo: Soportar 1000 logins simultáneos sin caída.  
- Pasos:  
  1. Ejecutar script de 1000 peticiones POST a /login.  
  2. Monitorizar CPU, memoria y errores.  
- Resultado esperado: <1% de errores, CPU <80%. 
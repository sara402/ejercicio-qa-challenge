// Author: Juan Pérez
// @ts-check
const { test, expect } = require('@playwright/test');

test.describe('Login Page Mercap', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('path/to/ejercicioQA-login.html');
  });

  test('Carga la página y muestra el título', async ({ page }) => {
    await expect(page.locator('text=Welcome')).toBeVisible();
  });

  test('Permite mostrar/ocultar contraseña', async ({ page }) => {
    const pwd = page.locator('#password');
    await pwd.fill('secret');
    await page.locator('button[data-action="toggle"]').click();
    await expect(pwd).toHaveAttribute('type', 'text');
    await page.locator('button[data-action="toggle"]').click();
    await expect(pwd).toHaveAttribute('type', 'password');
  });

  test('Valida login con credenciales vacías', async ({ page }) => {
    await page.locator('button[type="submit"]').click();
    await expect(page.locator('.js-required')).toBeVisible();
  });

  test('Redirige al signup desde "Don\'t have an account?"', async ({ page }) => {
    await page.locator('text=Don\'t have an account?').locator('a').click();
    await expect(page).toHaveURL(/.*\/u\/signup/);
  });

  test('Accede con Google', async ({ page }) => {
    await page.locator('form[data-provider="google"]').evaluate(form => form.submit());
  });
});

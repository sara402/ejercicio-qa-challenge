# Author: Juan Pérez
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

@pytest.fixture(scope="module")
def driver():
    service = Service(ChromeDriverManager().install())
    options = webdriver.ChromeOptions()
    options.add_argument("--headless")
    drv = webdriver.Chrome(service=service, options=options)
    yield drv
    drv.quit()

def test_carga_pagina_y_titulo(driver):
    driver.get("path/to/ejercicioQA-login.html")
    assert "Welcome" in driver.page_source

def test_toggle_password_visibility(driver):
    driver.get("path/to/ejercicioQA-login.html")
    pwd = driver.find_element(By.ID, "password")
    pwd.send_keys("secret")
    toggle = driver.find_element(By.CSS_SELECTOR, "button[data-action='toggle']")
    toggle.click()
    assert pwd.get_attribute("type") == "text"
    toggle.click()
    assert pwd.get_attribute("type") == "password"

def test_login_con_campos_vacios_muestra_error(driver):
    driver.get("path/to/ejercicioQA-login.html")
    driver.find_element(By.CSS_SELECTOR, "button[type='submit']").click()
    error = driver.find_element(By.CLASS_NAME, "js-required")
    assert error.is_displayed()

def test_redirige_signup(driver):
    driver.get("path/to/ejercicioQA-login.html")
    link = driver.find_element(By.LINK_TEXT, "Don't have an account?")
    link.click()
    assert "/u/signup" in driver.current_url

def test_login_google_submitea_form(driver):
    driver.get("path/to/ejercicioQA-login.html")
    form = driver.find_element(By.CSS_SELECTOR, "form[data-provider='google']")
    form.submit()

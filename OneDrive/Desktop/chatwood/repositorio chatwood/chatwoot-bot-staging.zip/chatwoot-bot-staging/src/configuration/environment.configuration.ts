export default () => ({
  nodeEnv: process.env.NODE_ENV,
  server: {
    port: Number(process.env.PORT),
  },
  database: {
    port: Number(process.env.DB_PORT),
    password: process.env.DB_PASSWORD,
    name: process.env.DB_NAME,
    host: process.env.DB_HOST,
    username: process.env.DB_USERNAME,
  },
  redis: {
    host: process.env.REDIS_HOST,
    port: Number(process.env.REDIS_PORT),
    testHost: process.env.REDIS_TEST_HOST,
  },
  chatwoot: {
    baseUrl: process.env.CHATWOOT_API_URL,
    apiAccessToken: process.env.CHATWOOT_API_ACCESS_TOKEN,
    accountId: process.env.CHATWOOT_ACCOUNT_ID,
  },
  openai: {
    apiKey: process.env.OPENAI_API_KEY,
    orgId: process.env.OPENAI_ORG_ID,
  },
  digitain: {
    secret: process.env.DIGITAIN_SECRET,
    apiUrl: process.env.DIGITAIN_API_URL,
    createUserUrl: process.env.DIGITAIN_CREATE_USER_URL,
    projectId: process.env.DIGITAIN_PROJECT_ID,
    emailDomain: process.env.DIGITAIN_EMAIL_DOMAIN,
    depositUrl: process.env.DIGITAIN_DEPOSIT_URL,
    getUserUrl: process.env.DIGITAIN_GET_USER_URL,
  },
  mp: {
    notificationUrl: process.env.NOTIFICATION_URL,
    accessToken: process.env.MERCADO_PAGO_ACCESS_TOKEN,
    returnUrl: process.env.RETURN_URL,
    apiUrl: process.env.MERCADO_PAGO_API_URL,
  },

  // auth: {
  //   secretKey: process.env.AUTH_SECRET_KEY,
  // },
});

import {
  HttpException,
  HttpStatus,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { IMercadoPagoRepository } from '../interface/mercado-pago.repository.interface';
import { MERCADO_PAGO_REPOSITORY } from '../interface/mercado-pago.repository.interface';
import { Inject } from '@nestjs/common';
import { MercadoPagoDomain } from '../../domain/mercado-pago.domain';
import { MercadoPagoAdapter } from '../../infrastructure/adapter/mercado-pago.adapter';
import { preferenceBodyMapper } from '../utils/preference-body.mapper';
import { CreatePaymentDto } from '../dto/create-payment.dto';
import {
  newPreferenceMapper,
  preferenceMapper,
} from '../mapper/mercado-pago.mapper';
import { PaymentCheckStatusResponse } from '../interface/payment-check-status-response.interface';
import { PreferenceStatus } from '../enum/preference-status.enum';
import { PaymentResponseDto } from '../dto/payment-response.dto';
import { UserService } from '@/modules/user/application/service/user.service';
import { TransactionsService } from '@/modules/transactions/application/service/transactions.service';

import { PaymentNotification } from '../dto/notification-payment.dto';
import { PaymentResult } from '@/modules/chatwoot/application/interfaces/payment-result.interface';
import { TokensService } from '@/modules/tokens/application/service/tokens.service';
import { DigitainService } from '@/modules/digitain/application/service/digitain.service';
import { PaymentMethodsService } from '@/modules/payment-methods/application/service/payment-methods.service';
import { PaymentMethod } from '@/modules/payment-methods/application/enum/payment-method.enum';
import { TransactionDomain } from '@/modules/transactions/domain/transaction.domain';
import { transactionDomainMapper } from '@/modules/transactions/application/utils/transactions.utils';
import { UserDomain } from '@/modules/user/domain/user.domain';

@Injectable()
export class MercadoPagoService {
  constructor(
    @Inject(MERCADO_PAGO_REPOSITORY)
    private readonly mercadoPagoRepository: IMercadoPagoRepository,
    private readonly mercadoPagoAdapter: MercadoPagoAdapter,
    private readonly transactionService: TransactionsService,
    private readonly userService: UserService,
    private readonly tokenService: TokensService,
    private readonly digitainService: DigitainService,
    private readonly paymentMethodsService: PaymentMethodsService,
  ) {}

  async createPayment(data: CreatePaymentDto): Promise<PaymentResponseDto> {
    try {
      //verifica si el usuario existe
      const user = await this.userService.getUserByUsername(data.username);
      if (!user) {
        throw new Error('El usuario no existe');
      }
      //verifica si el usuario tiene una transaccion pendiente
      const lastTransaction =
        await this.transactionService.getLastTransactionByUserId(user.id);

      if (lastTransaction) {
        if (lastTransaction.status === PreferenceStatus.PENDING) {
          throw new Error('El usuario ya tiene una transacción pendiente');
        }
      }
      //crea el body de la preferencia
      const preferenceBody = preferenceBodyMapper(data);
      const paymentResponse =
        await this.mercadoPagoAdapter.createPayment(preferenceBody);
      //crea el metodo de pago en la base de datos
      const paymentMethod = await this.paymentMethodsService.create({
        type: PaymentMethod.MERCADO_PAGO,
      });
      const mercadoPagoDomain = newPreferenceMapper(
        paymentResponse,
        paymentMethod.id,
      );
      //crea el pago en la base de datos
      await this.mercadoPagoRepository.create(mercadoPagoDomain);
      //crea la transaccion
      const transactionDomain = transactionDomainMapper(
        data.amount,
        user.id,
        paymentMethod,
      );
      await this.transactionService.createTransaction(transactionDomain);
      return {
        amount: data.amount,
        paymentLink: paymentResponse.init_point,
        idPaymentMethod: paymentMethod.id,
      };
    } catch (e) {
      throw new Error(e.message);
    }
  }

  async getPreferenceById(id: string): Promise<MercadoPagoDomain> {
    const preference = await this.mercadoPagoAdapter.getPreferenceById(
      Number(id),
    );

    const mercadoPagoEntity =
      await this.mercadoPagoRepository.getPreferenceByExternalReference(
        preference.external_reference,
      );

    const paymentMethod = await this.paymentMethodsService.findById(
      mercadoPagoEntity.idPaymentMethod,
    );
    return preferenceMapper(preference, paymentMethod);
  }

  async getPaymentStatus(id: number): Promise<PaymentCheckStatusResponse> {
    return await this.mercadoPagoAdapter.getPaymentStatus(id);
  }

  async updatePayment(
    id: number,
    data: Partial<MercadoPagoDomain>,
  ): Promise<MercadoPagoDomain> {
    return this.mercadoPagoRepository.update(id, data);
  }

  async getPaymentByExternalReference(
    externalReference: string,
  ): Promise<MercadoPagoDomain> {
    return await this.mercadoPagoRepository.getPreferenceByExternalReference(
      externalReference,
    );
  }

  async deletePayment(id: number): Promise<void> {
    try {
      return await this.mercadoPagoRepository.delete(id);
    } catch (e) {
      throw new HttpException(e.message, HttpStatus.BAD_REQUEST);
    }
  }

  async paymentProcessed(body: any) {
    const payment = await this.getPreferenceById(body.id);
    if (!payment) {
      throw new NotFoundException(`Payment with ID ${body.id} not found`);
    }
    return this.mercadoPagoRepository.update(body.id, {
      status: PreferenceStatus.APPROVED,
    });
  }

  async paymentApproved(
    mercadoPagoDomain: MercadoPagoDomain,
    transactionDomain: TransactionDomain,
    user: UserDomain,
  ): Promise<PaymentResult> {
    await this.updatePayment(mercadoPagoDomain.id, {
      status: PreferenceStatus.APPROVED,
    });

    await this.transactionService.updatePayment(transactionDomain.id, {
      status: PreferenceStatus.APPROVED,
    });

    const tokens = user.tokens;

    const newTokens = tokens.balance + transactionDomain.amount;

    await this.tokenService.uploadTokens(tokens.id, newTokens);

    await this.digitainService.deposit(
      transactionDomain.amount,
      transactionDomain.id,
      user.externalId,
    );

    return {
      userConversationId: user.conversationId,
      amount: transactionDomain.amount,
      username: user.username,
    };
  }

  async paymentPending(body: any) {
    const transaction = await this.getPreferenceById(body.id);
    if (!transaction) {
      throw new NotFoundException(`Transaction with ID ${body.id} not found`);
    }
    return this.mercadoPagoRepository.update(body.id, {
      status: PreferenceStatus.PENDING,
    });
  }

  async paymentRejected(
    mercadoPagoDomain: MercadoPagoDomain,
    transactionDomain: TransactionDomain,
    user: UserDomain,
  ): Promise<PaymentResult> {
    await this.updatePayment(mercadoPagoDomain.id, {
      status: PreferenceStatus.REJECTED,
    });

    await this.transactionService.updatePayment(transactionDomain.id, {
      status: PreferenceStatus.REJECTED,
    });

    return {
      userConversationId: user.conversationId,
      amount: transactionDomain.amount,
      username: user.username,
    };
  }

  async handleMPPaymentNotification(
    paymentNotification: PaymentNotification,
  ): Promise<{
    conversationId: number;
    username: string;
    amount?: number;
    status: PreferenceStatus;
  }> {
    const { type, action, data } = paymentNotification;

    if (type === 'payment' && action === 'payment.created') {
      const paymentNotificationId = Number(data.id);

      const mercadoPagoPayment = await this.getPaymentStatus(
        paymentNotificationId,
      );

      const mercadoPagoDomain = await this.getPaymentByExternalReference(
        mercadoPagoPayment.externalReference,
      );

      const transactionDomain =
        await this.transactionService.getTransactionByPaymentMethodId(
          mercadoPagoDomain.idPaymentMethod,
        );

      const user = await this.userService.getUserById(transactionDomain.userId);

      switch (mercadoPagoPayment.status) {
        case PreferenceStatus.APPROVED:
          if (mercadoPagoDomain.status === PreferenceStatus.PENDING) {
            const paymentApproved = await this.paymentApproved(
              mercadoPagoDomain,
              transactionDomain,
              user,
            );

            //falta enviar el mensaje al usuario
            return {
              conversationId: paymentApproved.userConversationId,
              username: paymentApproved.username,
              amount: paymentApproved.amount,
              status: PreferenceStatus.APPROVED,
            };
          }

        case PreferenceStatus.PENDING:
          if (mercadoPagoDomain.status === PreferenceStatus.PENDING) {
            await this.updatePayment(mercadoPagoDomain.id, {
              status: PreferenceStatus.PENDING,
            });
          }
          return {
            conversationId: user.conversationId,
            username: user.username,
            amount: transactionDomain.amount,
            status: PreferenceStatus.PENDING,
          };

        case PreferenceStatus.REJECTED:
          if (mercadoPagoDomain.status === PreferenceStatus.PENDING) {
            const paymentRejected = await this.paymentRejected(
              mercadoPagoDomain,
              transactionDomain,
              user,
            );
            //falta enviar el mensaje al usuario
            return {
              conversationId: paymentRejected.userConversationId,
              username: paymentRejected.username,
              amount: paymentRejected.amount,
              status: PreferenceStatus.REJECTED,
            };
          }

        default:
          return {
            conversationId: user.conversationId,
            username: user.username,
            amount: transactionDomain.amount,
            status: PreferenceStatus.PENDING,
          };
      }
    }
  }
}

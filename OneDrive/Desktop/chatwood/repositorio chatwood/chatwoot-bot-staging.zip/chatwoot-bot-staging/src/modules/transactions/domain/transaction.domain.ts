import { Base } from '@/common/domain/base.domain';
import { PreferenceStatus } from '@/modules/mp/application/enum/preference-status.enum';
import { PaymentMethodsDomain } from '@/modules/payment-methods/domain/payment-methods.domain';

export class TransactionDomain extends Base {
  userId: number;
  amount: number;
  status: PreferenceStatus;
  paymentMethod: PaymentMethodsDomain;
}

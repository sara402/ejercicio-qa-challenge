export function initialMessageSelect() {
  return {
    content: '¡Hola! Bienvenido a azarlatino.com, ¿en qué puedo ayudarte hoy?',
    content_type: 'text',
    private: false,
  };
}

export function userRegistered(username: string, password: string) {
  return {
    content: `Usuario creado exitosamente!\n\n👤 Tu usuario: ${username}\n\n🔐 Tu contraseña: ${password}\n\n ♠️ Carga mínima $1.000 (mil pesos)\n\n ♠️ Retiro mínimo $3.000 (tres mil pesos)\n\n♣️ Acá te enviamos el link para comenzar a jugar.\n\n https://azarlatino1.com/es/ \n\n`,
    content_type: 'text',
    private: false,
  };
}

export function formatChatwootMessage(message: string) {
  return {
    content: message,
    content_type: 'text',
    private: false,
  };
}

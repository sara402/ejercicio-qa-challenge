import { Injectable } from '@nestjs/common';
import { DigitainDomain } from '../../domain/digitain.domain';
import { DigitainAdapter } from '../../infrastructure/adapter/digitain.adapter';
import { GetPlayerDigitainResponse } from '../dto/response/get-player.digitain.response';
@Injectable()
export class DigitainService {
  constructor(private readonly digitainAdapter: DigitainAdapter) {}

  async createUser(user: DigitainDomain): Promise<DigitainDomain> {
    const response = await this.digitainAdapter.createUser(user);
    if (response.ResultCode === 5) {
      throw new Error('El usuario ya existe en Digitain');
    }

    if (response.ResultCode !== 0) {
      throw new Error(`Error de Digitain: ${response.Message}`);
    }

    return {
      ...user,
      externalId: response.Value,
    };
  }

  async deposit(
    amount: number,
    transactionId: number,
    playerId: string,
  ): Promise<void> {
    const object = {
      PlayerId: playerId,
      Amount: amount,
      TransactionId: transactionId,
    };
    await this.digitainAdapter.deposit(object);
    console.log(
      `Deposito exitoso ${amount} con transactionId ${transactionId}`,
    );
  }

  async getUser(username: string): Promise<GetPlayerDigitainResponse | null> {
    try {
      const response = await this.digitainAdapter.getUserByUsername(username);
      return response;
    } catch (error) {
      return null;
    }
  }
}

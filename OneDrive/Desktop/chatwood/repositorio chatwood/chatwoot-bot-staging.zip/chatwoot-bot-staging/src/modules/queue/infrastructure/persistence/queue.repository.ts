import { InjectQueue } from '@nestjs/bull';
import { Injectable } from '@nestjs/common';
import { Queue } from 'bull';
import { IQueueProcessorRepository } from '../../application/interface/queue.processor.repository';
import { ConversationDTO } from '@/modules/chatwoot/application/dto/conversation.dto';

@Injectable()
export class QueueRepository implements IQueueProcessorRepository {
  constructor(
    @InjectQueue('message') private messageQueue: Queue,
    @InjectQueue('payment-notification')
    private paymentNotificationQueue: Queue,
  ) {
    // Get Redis client from Bull queue
    const redisClient = this.messageQueue.client;

    // Log queue events to Redis logs
    this.messageQueue.on('waiting', (jobId) => {
      redisClient.publish(
        'logs',
        `[MESSAGE_QUEUE] Job ${jobId} waiting to be processed`,
      );
    });

    this.paymentNotificationQueue.on('waiting', (jobId) => {
      redisClient.publish(
        'logs',
        `[PAYMENT_QUEUE] Job ${jobId} waiting to be processed`,
      );
    });
  }

  async addToMessageQueue(messageJob: ConversationDTO): Promise<void> {
    const jobId = `message-${messageJob.messages[0].conversation_id}-${Date.now()}`;

    // Log to Redis
    await this.messageQueue.client.publish(
      'logs',
      JSON.stringify({
        type: 'MESSAGE_QUEUE',
        action: 'ADD',
        jobId,
        conversationId: messageJob.messages[0].conversation_id,
        timestamp: new Date().toISOString(),
      }),
    );

    await this.messageQueue.add(messageJob, {
      jobId,
      removeOnComplete: true,
      removeOnFail: true,
    });
  }

  async addToPaymentNotificationQueue(messageJob: any): Promise<void> {
    const jobId = `payment-notification-${messageJob.conversation_id}-${Date.now()}`;

    // Log to Redis
    await this.paymentNotificationQueue.client.publish(
      'logs',
      JSON.stringify({
        type: 'PAYMENT_QUEUE',
        action: 'ADD',
        jobId,
        conversationId: messageJob.conversation_id,
        timestamp: new Date().toISOString(),
      }),
    );

    await this.paymentNotificationQueue.add(messageJob, {
      jobId,
      removeOnComplete: true,
      removeOnFail: true,
    });
  }
}

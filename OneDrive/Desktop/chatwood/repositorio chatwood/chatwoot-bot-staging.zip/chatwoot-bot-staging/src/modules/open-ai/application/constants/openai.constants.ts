import { ResponseFormatText } from 'openai/resources';

export const openAIModel = 'gpt-4o-mini';
export const temperature = 0.2;
export const maxCompletionTokens = 1024;
export const topP = 0.1;
export const frequencyPenalty = 0.7;
export const presencePenalty = 0.1;
export const responseFormat: ResponseFormatText = { type: 'text' };

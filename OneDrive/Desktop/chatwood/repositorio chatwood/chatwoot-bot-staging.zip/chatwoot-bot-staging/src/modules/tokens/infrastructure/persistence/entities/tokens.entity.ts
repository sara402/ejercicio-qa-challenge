import { Column, Entity, OneToOne } from 'typeorm';
import { Base } from '@/common/infrastructure/entities/base.entity';
import { UserEntity } from '@/modules/user/infrastructure/persistence/entities/user.entity';

@Entity('tokens')
export class TokensEntity extends Base {
  @Column({ type: 'float', default: 0 })
  balance: number;

  @Column({ type: 'float', default: 0 })
  withdrawableBalance: number;

  @OneToOne(() => UserEntity, (user) => user.tokens)
  user: UserEntity;
}

import { Controller, Post, Body } from '@nestjs/common';
import { MercadoPagoService } from '../application/service/mercado-pago.service';

@Controller('mp')
export class MercadoPagoController {
  constructor(private readonly mercadoPagoService: MercadoPagoService) {}

  // @Post('processed')
  // async processed(@Body() body: any) {
  //   return this.mercadoPagoService.paymentProcessed(body);
  // }

  // @Post('pending')
  // async pending(@Body() body: any) {
  //   return this.mercadoPagoService.paymentPending(body);
  // }

  // @Post('rejected')
  // async rejected(@Body() body: any) {
  //   return this.mercadoPagoService.paymentRejected(body);
  // }
}

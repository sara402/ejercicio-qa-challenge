export enum OpenAiMessageTypes {
  FUNCTION = 'function',
  TEXT = 'text',
}

import { Base } from '@/common/infrastructure/entities/base.entity';
import { MercadoPagoEntity } from '@/modules/mp/infrastructure/persistence/entities/mercado-pago.entity';
import { TransactionsEntity } from '@/modules/transactions/infrastructure/persistence/entities/transactions.entity';
import { Column, Entity, OneToMany, OneToOne } from 'typeorm';
import { PaymentMethod } from '@/modules/payment-methods/application/enum/payment-method.enum';

@Entity('payment_methods')
export class PaymentMethodsEntity extends Base {
  @Column()
  type: PaymentMethod;

  @OneToOne(() => MercadoPagoEntity, (mercadoPago) => mercadoPago.paymentMethod)
  mercadoPago: MercadoPagoEntity[];

  @OneToMany(
    () => TransactionsEntity,
    (transaction) => transaction.paymentMethod,
  )
  transactions: TransactionsEntity[];
}

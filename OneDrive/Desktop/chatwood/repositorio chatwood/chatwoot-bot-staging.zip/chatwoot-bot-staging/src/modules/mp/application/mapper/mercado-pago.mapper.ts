import { MercadoPagoDomain } from '../../domain/mercado-pago.domain';
import { PreferenceResponse } from 'mercadopago/dist/clients/preference/commonTypes';
import { PreferenceStatus } from '../enum/preference-status.enum';
import { PaymentResponse } from 'mercadopago/dist/clients/payment/commonTypes';
import { PaymentMethodsEntity } from '@/modules/payment-methods/infrastucture/persistence/entities/payment-methods.entity';

export function newPreferenceMapper(
  data: PreferenceResponse,
  paymentMethodId: number,
): MercadoPagoDomain {
  const mercadoPagoDomain = new MercadoPagoDomain();
  mercadoPagoDomain.status = PreferenceStatus.PENDING;
  mercadoPagoDomain.externalReference = data.external_reference;
  mercadoPagoDomain.preferenceId = data.id;
  mercadoPagoDomain.idPaymentMethod = paymentMethodId;
  return mercadoPagoDomain;
}

export function preferenceMapper(
  data: PaymentResponse,
  paymentMethod: PaymentMethodsEntity,
): MercadoPagoDomain {
  const mercadoPagoDomain = new MercadoPagoDomain();
  mercadoPagoDomain.externalReference = data.external_reference;
  mercadoPagoDomain.preferenceId = data.id.toString();
  mercadoPagoDomain.status = data.status;
  mercadoPagoDomain.idPaymentMethod = paymentMethod.id;
  return mercadoPagoDomain;
}

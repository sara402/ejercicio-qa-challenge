import { TransactionsService } from './application/service/transactions.service';
import { TransactionsEntity } from './infrastructure/persistence/entities/transactions.entity';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Module } from '@nestjs/common';
import { TRANSACTIONS_REPOSITORY } from './application/interface/transactions.repository.interface';
import { TransactionsPostgreSQLRepository } from './infrastructure/persistence/transactions.postgresql.repository';
@Module({
  imports: [
    TypeOrmModule.forFeature([TransactionsEntity], process.env.DB_NAME),
  ],
  providers: [
    TransactionsService,
    {
      provide: TRANSACTIONS_REPOSITORY,
      useClass: TransactionsPostgreSQLRepository,
    },
  ],
  exports: [TransactionsService],
})
export class TransactionsModule {}

export class PaymentResponseDto {
  paymentLink: string;
  amount: number;
  idPaymentMethod: number;
}

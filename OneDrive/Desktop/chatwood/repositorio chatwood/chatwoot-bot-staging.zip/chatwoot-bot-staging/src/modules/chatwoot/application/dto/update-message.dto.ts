export class UpdateMessageDTO {
  account: {
    id: number;
    name: string;
  };
  additional_attributes: Record<string, any>;
  content_attributes: {
    items: Array<{
      title: string;
      value: string;
    }>;
    submitted_values?: Array<{
      title: string;
      value: string;
    }>;
  };
  content_type: string;
  content: string;
  conversation: {
    additional_attributes: {
      browser: {
        device_name: string;
        browser_name: string;
        platform_name: string;
        browser_version: string;
        platform_version: string;
      };
      referer: string;
      initiated_at: {
        timestamp: string;
      };
      browser_language: string;
    };
    can_reply: boolean;
    channel: string;
    contact_inbox: {
      id: number;
      contact_id: number;
      inbox_id: number;
      source_id: string;
      created_at: string;
      updated_at: string;
      hmac_verified: boolean;
      pubsub_token: string;
    };
    id: number;
    inbox_id: number;
    messages: Array<{
      id: number;
      content: string;
      account_id: number;
      inbox_id: number;
      conversation_id: number;
      message_type: number;
      created_at: number;
      updated_at: string;
      private: boolean;
      status: string;
      source_id: string | null;
      content_type: string;
      content_attributes: {
        items: Array<{
          title: string;
          value: string;
        }>;
        submitted_values: Array<{
          title: string;
          value: string;
        }>;
      };
      sender_type: string;
      sender_id: number;
      external_source_ids: Record<string, any>;
      additional_attributes: Record<string, any>;
      processed_message_content: string;
      sentiment: Record<string, any>;
      conversation: {
        assignee_id: number;
        unread_count: number;
        last_activity_at: number;
        contact_inbox: {
          source_id: string;
        };
      };
      sender: {
        id: number;
        name: string;
        available_name: string;
        avatar_url: string;
        type: string;
        availability_status: string | null;
        thumbnail: string;
      };
    }>;
    labels: Array<any>;
    meta: {
      sender: {
        additional_attributes: Record<string, any>;
        custom_attributes: Record<string, any>;
        email: string | null;
        id: number;
        identifier: string | null;
        name: string;
        phone_number: string;
        thumbnail: string;
        type: string;
      };
      assignee: {
        id: number;
        name: string;
        available_name: string;
        avatar_url: string;
        type: string;
        availability_status: string | null;
        thumbnail: string;
      };
      team: any | null;
      hmac_verified: boolean;
    };
    status: string;
    custom_attributes: Record<string, any>;
    snoozed_until: any | null;
    unread_count: number;
    first_reply_created_at: string;
    priority: any | null;
    waiting_since: number;
    agent_last_seen_at: number;
    contact_last_seen_at: number;
    last_activity_at: number;
    timestamp: number;
    created_at: number;
  };
  created_at: string;
  id: number;
  inbox: {
    id: number;
    name: string;
  };
  message_type: string;
  private: boolean;
  sender: {
    id: number;
    name: string;
    email: string;
    type: string;
  };
  source_id: string | null;
  event: string;
}

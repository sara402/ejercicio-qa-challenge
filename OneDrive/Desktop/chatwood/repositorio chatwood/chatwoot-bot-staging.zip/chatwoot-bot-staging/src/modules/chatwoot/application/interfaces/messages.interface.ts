interface MessagePayload {
  sender: {
    type: 'contact' | 'assistant' | 'system';
  };
  content: string;
}
interface MappedMessage {
  role: 'user' | 'assistant';
  content: {
    type: 'text';
    text: string;
  }[];
}

import { Body, Controller, Post, Res } from '@nestjs/common';
import { QueueService } from '../application/service/queue.service';
import { ConversationDTO } from '@/modules/chatwoot/application/dto/conversation.dto';
import { Response } from 'express';

@Controller('queue')
export class QueueController {
  constructor(private readonly queueService: QueueService) {}

  @Post('message')
  async newMessage(@Body() req: ConversationDTO): Promise<any> {
    return await this.queueService.addMessageToQueue(req);
  }

  @Post('mp-notification')
  async notification(@Body() body: any, @Res() response: Response) {
    const success = await this.queueService.paymentNotification(body);
    if (success) {
      return response.status(200).send();
    }
    return response.status(400).send();
  }
}

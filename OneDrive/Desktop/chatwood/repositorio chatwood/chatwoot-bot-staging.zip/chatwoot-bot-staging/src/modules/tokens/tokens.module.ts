import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CommonModule } from '@/common/common.module';
import { TOKENS_REPOSITORY } from './application/interface/tokens.repository.interface';
import { TokensService } from './application/service/tokens.service';
import { TokensEntity } from './infrastructure/persistence/entities/tokens.entity';
import { TokensPostgreSQLRepository } from './infrastructure/persistence/tokens.postgresql.repository';

@Module({
  imports: [
    TypeOrmModule.forFeature([TokensEntity], process.env.DB_NAME),
    CommonModule,
  ],
  providers: [
    TokensService,
    {
      provide: TOKENS_REPOSITORY,
      useClass: TokensPostgreSQLRepository,
    },
  ],
  exports: [TokensService],
})
export class TokensModule {}

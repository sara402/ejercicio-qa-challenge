import { CommonModule } from '@/common/common.module';
import { Module } from '@nestjs/common';
import { OpenAiService } from './application/service/open-ai.service';
import { OpenAiAdapter } from './infrastructure/adapter/openai.adapter';

@Module({
  imports: [CommonModule],
  providers: [OpenAiService, OpenAiAdapter],
  exports: [OpenAiService],
})
export class OpenAiModule {}

import { Process, Processor } from '@nestjs/bull';
import { Job } from 'bull';
import { MercadoPagoService } from '@/modules/mp/application/service/mercado-pago.service';
import { ChatwootService } from '@/modules/chatwoot/application/service/chatwoot.service';
import { PreferenceStatus } from '@/modules/mp/application/enum/preference-status.enum';
@Processor('payment-notification')
export class PaymentNotificationProcessor {
  constructor(
    private readonly mercadoPagoService: MercadoPagoService,
    private readonly chatwootService: ChatwootService,
  ) {}

  @Process({
    concurrency: 10,
  })
  async PaymentNotificationProcessor(job: Job<any>) {
    try {
      const mercadoPago =
        await this.mercadoPagoService.handleMPPaymentNotification(job.data);
      switch (mercadoPago.status) {
        case PreferenceStatus.APPROVED:
          await this.chatwootService.sendPaymentProcessedMessage(
            mercadoPago.conversationId,
            mercadoPago.amount,
            mercadoPago.username,
          );
          break;
        case PreferenceStatus.PENDING:
          await this.chatwootService.sendPaymentPendingMessage(
            mercadoPago.conversationId,
            mercadoPago.username,
          );
          break;
        case PreferenceStatus.REJECTED:
          await this.chatwootService.sendPaymentRejectedMessage(
            mercadoPago.conversationId,
            mercadoPago.username,
          );
          break;
        default:
          break;
      }
    } catch (error) {
      console.error(
        `Error processing payment notification for conversation ${job.data.id}:`,
        error,
      );
      throw error;
    }
  }
}

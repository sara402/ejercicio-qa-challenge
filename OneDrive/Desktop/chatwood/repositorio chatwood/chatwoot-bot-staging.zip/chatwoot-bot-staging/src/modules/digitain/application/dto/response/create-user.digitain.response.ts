export class CreateUserDigitainResponse {
  Message: string;
  ResultCode: number;
  Value: string | null;
}

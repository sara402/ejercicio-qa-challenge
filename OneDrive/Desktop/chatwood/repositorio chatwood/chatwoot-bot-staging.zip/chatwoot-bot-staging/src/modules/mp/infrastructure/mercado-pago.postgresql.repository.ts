import {
  Injectable,
  NotFoundException,
  InternalServerErrorException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { MercadoPagoEntity } from './persistence/entities/mercado-pago.entity';
import { Repository } from 'typeorm';
import { IMercadoPagoRepository } from '../application/interface/mercado-pago.repository.interface';
import { MercadoPagoDomain } from '../domain/mercado-pago.domain';

@Injectable()
export class MercadoPagoPostgreSQLRepository implements IMercadoPagoRepository {
  constructor(
    @InjectRepository(MercadoPagoEntity, process.env.DB_NAME)
    private readonly mercadoPagoRepository: Repository<MercadoPagoEntity>,
  ) {}

  async create(
    mercadoPagoInformation: MercadoPagoDomain,
  ): Promise<MercadoPagoEntity> {
    try {
      const mercadoPagoEntity = this.mercadoPagoRepository.create(
        mercadoPagoInformation,
      );
      return await this.mercadoPagoRepository.save(mercadoPagoEntity);
    } catch (error) {
      throw new InternalServerErrorException('Failed to create transaction');
    }
  }

  async findById(id: number): Promise<MercadoPagoEntity> {
    try {
      const transaction = await this.mercadoPagoRepository.findOne({
        where: { id },
      });
      if (!transaction) {
        throw new NotFoundException(`Transaction with ID ${id} not found`);
      }
      return transaction;
    } catch (error) {
      throw new InternalServerErrorException('Failed to retrieve transaction');
    }
  }

  async update(
    id: number,
    data: Partial<MercadoPagoDomain>,
  ): Promise<MercadoPagoEntity> {
    try {
      const transactionUpdate = await this.mercadoPagoRepository.preload({
        id,
        ...data,
      });

      if (!transactionUpdate) {
        throw new Error(`transaction #${id} do not exist`);
      }

      return await this.mercadoPagoRepository.save(transactionUpdate);
    } catch (e) {
      throw new Error(e.message);
    }
  }

  async getPreferenceByExternalReference(
    externalReference: string,
  ): Promise<MercadoPagoEntity> {
    return await this.mercadoPagoRepository.findOne({
      where: { externalReference },
    });
  }

  async getPreferenceByPreferenceId(id: string): Promise<MercadoPagoEntity> {
    return await this.mercadoPagoRepository.findOne({
      where: { preferenceId: id },
    });
  }

  async delete(id: number): Promise<void> {
    try {
      await this.mercadoPagoRepository.softDelete(id);
    } catch (error) {
      throw new InternalServerErrorException('Failed to delete transaction');
    }
  }
}

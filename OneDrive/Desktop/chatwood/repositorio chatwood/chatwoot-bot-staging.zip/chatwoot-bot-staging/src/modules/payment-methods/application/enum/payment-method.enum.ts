export enum PaymentMethod {
  MERCADO_PAGO = 'mercado_pago',
}

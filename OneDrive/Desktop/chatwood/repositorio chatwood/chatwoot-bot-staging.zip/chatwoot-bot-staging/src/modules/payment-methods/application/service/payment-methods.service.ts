import { Inject } from '@nestjs/common';
import { Injectable } from '@nestjs/common';
import { PAYMENT_METHODS_REPOSITORY } from '../interface/payment-methods.repository.interface';
import { IPaymentMethodsRepository } from '../interface/payment-methods.repository.interface';
import { PaymentMethodsEntity } from '../../infrastucture/persistence/entities/payment-methods.entity';
import { PaymentMethodsDomain } from '../../domain/payment-methods.domain';

@Injectable()
export class PaymentMethodsService {
  constructor(
    @Inject(PAYMENT_METHODS_REPOSITORY)
    private readonly paymentMethodsRepository: IPaymentMethodsRepository,
  ) {}

  async findAll(): Promise<PaymentMethodsEntity[]> {
    return this.paymentMethodsRepository.findAll();
  }

  async findById(id: number): Promise<PaymentMethodsEntity> {
    return this.paymentMethodsRepository.findById(id);
  }

  async create(
    paymentMethods: PaymentMethodsDomain,
  ): Promise<PaymentMethodsDomain> {
    return this.paymentMethodsRepository.create(paymentMethods);
  }

  async update(
    id: number,
    paymentMethods: PaymentMethodsDomain,
  ): Promise<PaymentMethodsEntity> {
    return this.paymentMethodsRepository.update(id, paymentMethods);
  }

  async delete(id: number): Promise<void> {
    return this.paymentMethodsRepository.delete(id);
  }
}

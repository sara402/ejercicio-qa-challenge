import { IsString, IsNumber, IsBoolean, IsDateString } from 'class-validator';

class PaymentDataDTO {
  @IsString()
  id: string;
}

export class PaymentNotificationDTO {
  @IsString()
  action: string;

  @IsString()
  api_version: string;

  data: PaymentDataDTO;

  @IsDateString()
  date_created: string;

  @IsNumber()
  id: number;

  @IsBoolean()
  live_mode: boolean;

  @IsString()
  type: string;

  @IsString()
  user_id: string;
}

import { CommonModule } from '@/common/common.module';
import { BullModule } from '@nestjs/bull';
import { Module, forwardRef } from '@nestjs/common';
import { MessageProcessor } from './application/service/processor/message.processor';
import { QueueService } from './application/service/queue.service';
import { QueueRepository } from './infrastructure/persistence/queue.repository';
import { QueueController } from './controller/queue.controller';
import { QUEUE_PROCESSOR_REPOSITORY } from './application/interface/queue.processor.repository';
import { ChatwootModule } from '../chatwoot/chatwoot.module';
import { PaymentNotificationProcessor } from './application/service/processor/payment-notification.processor';
import { MercadoPagoModule } from '../mp/mercado-pago.module';
@Module({
  imports: [
    BullModule.registerQueue({
      name: 'message',
      defaultJobOptions: {
        attempts: 1,
        timeout: 10000,
      },
    }),
    BullModule.registerQueue({
      name: 'payment-notification',
      defaultJobOptions: {
        attempts: 1,
        timeout: 10000,
      },
    }),
    CommonModule,
    forwardRef(() => ChatwootModule),
    forwardRef(() => MercadoPagoModule),
  ],
  controllers: [QueueController],
  providers: [
    MessageProcessor,
    QueueService,
    PaymentNotificationProcessor,
    {
      provide: QUEUE_PROCESSOR_REPOSITORY,
      useClass: QueueRepository,
    },
  ],
  exports: [QueueService],
})
export class QueueModule {}

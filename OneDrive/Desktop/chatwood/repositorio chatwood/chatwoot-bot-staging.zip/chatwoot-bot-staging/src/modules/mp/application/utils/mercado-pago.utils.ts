import { TransactionDomain } from '@/modules/transactions/domain/transaction.domain';
import { PreferenceStatus } from '../enum/preference-status.enum';
import { PaymentMethodsDomain } from '@/modules/payment-methods/domain/payment-methods.domain';

export function transactionMapper(
  userId: number,
  amount: number,
  paymentMethod: PaymentMethodsDomain,
): TransactionDomain {
  const transactionDomain = new TransactionDomain();
  transactionDomain.userId = userId;
  transactionDomain.amount = amount;
  transactionDomain.status = PreferenceStatus.PENDING;
  transactionDomain.paymentMethod = paymentMethod;
  return transactionDomain;
}

export function verifyLastTransaction(
  lastTransaction: TransactionDomain,
): boolean {
  if (lastTransaction) {
    if (lastTransaction.status === PreferenceStatus.PENDING) {
      throw new Error('El usuario ya tiene una transacción pendiente');
    }
  }
  return true;
}

import { CommonModule } from '@/common/common.module';
import { ChatwootService } from './application/service/chatwoot.service';
import { Module, forwardRef } from '@nestjs/common';
import { UserModule } from '../user/user.module';
import { ChatwootAdapter } from './infrastructure/adapter/chatwoot.adapter';
import { OpenAiModule } from '../open-ai/open-ai.module';
import { DigitainModule } from '../digitain/digitain.module';
import { MercadoPagoModule } from '../mp/mercado-pago.module';
@Module({
  imports: [
    CommonModule,
    UserModule,
    OpenAiModule,
    DigitainModule,
    forwardRef(() => MercadoPagoModule),
  ],
  providers: [ChatwootService, ChatwootAdapter],
  exports: [ChatwootService, ChatwootAdapter],
})
export class ChatwootModule {}

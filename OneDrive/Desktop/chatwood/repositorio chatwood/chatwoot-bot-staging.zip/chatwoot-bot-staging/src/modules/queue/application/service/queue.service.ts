import { Inject, Injectable } from '@nestjs/common';
import { IQueueProcessorRepository } from '../interface/queue.processor.repository';
import { QUEUE_PROCESSOR_REPOSITORY } from '../interface/queue.processor.repository';
import { ConversationDTO } from '@/modules/chatwoot/application/dto/conversation.dto';
import { PaymentNotificationDTO } from '../dto/payment-notification.dto';
import { validate } from 'class-validator';

@Injectable()
export class QueueService {
  constructor(
    @Inject(QUEUE_PROCESSOR_REPOSITORY)
    private readonly queueProcessorRepository: IQueueProcessorRepository,
  ) {}

  async addMessageToQueue(message: ConversationDTO): Promise<void> {
    const isSoporte: boolean = message.meta.sender.custom_attributes['support'];
    if (!isSoporte) {
      await this.queueProcessorRepository.addToMessageQueue(message);
    }
  }

  async paymentNotification(body: any): Promise<boolean> {
    const paymentNotification = new PaymentNotificationDTO();
    Object.assign(paymentNotification, body);

    const errors = await validate(paymentNotification);
    if (errors.length > 0) {
      return true;
    }

    await this.queueProcessorRepository.addToPaymentNotificationQueue(
      paymentNotification,
    );
    return true;
  }
}

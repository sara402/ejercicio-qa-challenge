import { Inject, Injectable } from '@nestjs/common';
import { TokensDomain } from '../../domain/tokens.domain';
import {
  ITokensRepository,
  TOKENS_REPOSITORY,
} from '../interface/tokens.repository.interface';

@Injectable()
export class TokensService {
  constructor(
    @Inject(TOKENS_REPOSITORY)
    private readonly tokensRepository: ITokensRepository,
  ) {}

  async uploadTokens(tokenId: number, balance: number): Promise<TokensDomain> {
    const tokens = await this.tokensRepository.getTokensById(tokenId);
    const cotization = Number(process.env.COTIZATION);

    if (tokens) {
      const newBalance = tokens.balance + balance * cotization;
      const newWithdrawableBalance =
        tokens.withdrawableBalance + balance * cotization;
      return this.tokensRepository.update(tokens.id, {
        balance: newBalance,
        withdrawableBalance: newWithdrawableBalance,
      });
    }
    return tokens;
  }

  async getTokensById(id: number): Promise<TokensDomain> {
    return this.tokensRepository.getTokensById(id);
  }

  async delete(id: number): Promise<void> {
    try {
      const tokens = await this.tokensRepository.getTokensById(id);
      if (tokens) {
        return this.tokensRepository.delete(id);
      }
    } catch (e) {
      throw new Error(e.message);
    }
  }
}

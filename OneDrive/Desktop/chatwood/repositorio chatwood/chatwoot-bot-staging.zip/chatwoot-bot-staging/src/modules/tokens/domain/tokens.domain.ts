import { Base } from '@/common/domain/base.domain';

export class TokensDomain extends Base {
  balance: number;
  withdrawableBalance: number;
}

export interface PaymentResult {
  userConversationId: number;
  amount: number;
  username: string;
}

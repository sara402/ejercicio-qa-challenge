import { ConversationDTO } from '@/modules/chatwoot/application/dto/conversation.dto';

export const QUEUE_PROCESSOR_REPOSITORY = 'QUEUE_PROCESSOR_REPOSITORY';

export interface IQueueProcessorRepository {
  addToMessageQueue(messageJob: ConversationDTO): Promise<void>;
  addToPaymentNotificationQueue(messageJob: any): Promise<void>;
}

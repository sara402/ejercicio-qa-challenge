import { forwardRef, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { MercadoPagoService } from './application/service/mercado-pago.service';
import { MercadoPagoEntity } from './infrastructure/persistence/entities/mercado-pago.entity';
import { CommonModule } from '@/common/common.module';
import { MercadoPagoPostgreSQLRepository } from './infrastructure/mercado-pago.postgresql.repository';
import { MERCADO_PAGO_REPOSITORY } from './application/interface/mercado-pago.repository.interface';
import { MercadoPagoAdapter } from './infrastructure/adapter/mercado-pago.adapter';
import { MercadoPagoController } from './controller/mercado-pago.controller';
import { TransactionsModule } from '@/modules/transactions/transactions.module';
import { UserModule } from '../user/user.module';
import { TokensModule } from '../tokens/tokens.module';
import { ChatwootModule } from '../chatwoot/chatwoot.module';
import { PaymentMethodsModule } from '../payment-methods/payment-methods.module';
import { DigitainModule } from '../digitain/digitain.module';
@Module({
  imports: [
    TypeOrmModule.forFeature([MercadoPagoEntity], process.env.DB_NAME),
    UserModule,
    TokensModule,
    PaymentMethodsModule,
    TransactionsModule,
    DigitainModule,
    forwardRef(() => ChatwootModule),
  ],
  providers: [
    MercadoPagoService,
    {
      provide: MERCADO_PAGO_REPOSITORY,
      useClass: MercadoPagoPostgreSQLRepository,
    },
    MercadoPagoAdapter,
  ],
  controllers: [MercadoPagoController],
  exports: [MercadoPagoService],
})
export class MercadoPagoModule {}

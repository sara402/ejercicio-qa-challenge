import { Base } from '@/common/infrastructure/entities/base.entity';
import { Column, Entity, JoinColumn, OneToOne } from 'typeorm';
import { PaymentMethodsEntity } from '@/modules/payment-methods/infrastucture/persistence/entities/payment-methods.entity';

@Entity({ name: 'mercado_pago' })
export class MercadoPagoEntity extends Base {
  @Column()
  idPaymentMethod: number;

  @Column()
  preferenceId: string;

  @Column()
  externalReference: string;

  @Column()
  status: string;

  @OneToOne(
    () => PaymentMethodsEntity,
    (paymentMethods) => paymentMethods.mercadoPago,
  )
  @JoinColumn({ name: 'id_payment_method' })
  paymentMethod: PaymentMethodsEntity;
}

import { Module } from '@nestjs/common';
import { CommonModule } from '@/common/common.module';
import { DigitainService } from './application/service/digitain.service';
import { DigitainAdapter } from './infrastructure/adapter/digitain.adapter';
@Module({
  imports: [CommonModule],
  providers: [DigitainService, DigitainAdapter],
  exports: [DigitainService],
})
export class DigitainModule {}

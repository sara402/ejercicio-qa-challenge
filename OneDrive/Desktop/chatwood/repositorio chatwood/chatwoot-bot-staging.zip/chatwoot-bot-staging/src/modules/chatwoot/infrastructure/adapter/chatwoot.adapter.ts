import {
  formatChatwootMessage,
  initialMessageSelect,
  userRegistered,
} from '@/modules/chatwoot/application/utils/messages.utils';
import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import axios, { AxiosRequestConfig } from 'axios';
import { AgentDerivationResponse } from '../../application/interfaces/agent.interface';

@Injectable()
export class ChatwootAdapter {
  private readonly CHATWOOT_API_URL: string;
  private readonly CHATWOOT_API_ACCESS_TOKEN: string;
  private readonly CHATWOOT_ACCOUNT_ID: number;

  constructor(private readonly environmentConfig: ConfigService) {
    this.CHATWOOT_API_URL = this.environmentConfig.get('chatwoot.baseUrl');
    this.CHATWOOT_API_ACCESS_TOKEN = this.environmentConfig.get(
      'chatwoot.apiAccessToken',
    );
    this.CHATWOOT_ACCOUNT_ID = this.environmentConfig.get('chatwoot.accountId');
  }

  private createRequestConfig(
    conversationId: number,
    data: object,
  ): AxiosRequestConfig {
    return {
      baseURL: this.CHATWOOT_API_URL,
      method: 'post',
      url: `${this.CHATWOOT_ACCOUNT_ID}/conversations/${conversationId}/messages`,
      headers: {
        'Content-Type': 'application/json',
        api_access_token: this.CHATWOOT_API_ACCESS_TOKEN,
      },
      data,
    };
  }

  private assignRegisteredUserLabelConfig(
    conversationId: number,
    data: object,
  ): AxiosRequestConfig {
    return {
      baseURL: this.CHATWOOT_API_URL,
      method: 'post',
      url: `${this.CHATWOOT_ACCOUNT_ID}/conversations/${conversationId}/labels`,
      headers: {
        'Content-Type': 'application/json',
        api_access_token: this.CHATWOOT_API_ACCESS_TOKEN,
      },
      data,
    };
  }

  private createRequestContactConfig(
    contactId: number,
    data: object,
  ): AxiosRequestConfig {
    return {
      baseURL: this.CHATWOOT_API_URL,
      method: 'put',
      url: `${this.CHATWOOT_ACCOUNT_ID}/contacts/${contactId}`,
      headers: {
        'Content-Type': 'application/json',
        api_access_token: this.CHATWOOT_API_ACCESS_TOKEN,
      },
      data,
    };
  }

  async sendNewConversationMessage(conversationId: number): Promise<any> {
    const data = initialMessageSelect();
    const requestConfig = this.createRequestConfig(conversationId, data);
    await axios(requestConfig);
  }

  async sendMessageToChatwoot(
    conversationId: number,
    message: string,
  ): Promise<any> {
    const data = formatChatwootMessage(message);
    const requestConfig = this.createRequestConfig(conversationId, data);
    await axios(requestConfig);
  }

  async sendUserRegistrationMessage(
    conversationId: number,
    username: string,
    password: string,
  ): Promise<any> {
    const data = userRegistered(username, password);
    const requestConfig = this.createRequestConfig(conversationId, data);
    await axios(requestConfig);
  }

  async contactUpdate(
    contactId: number,
    idRegistroAi: string,
    username: string,
    nombre: string,
  ) {
    const data = {
      custom_attributes: {
        id_registro_ai: idRegistroAi,
        username: username,
        nombre: nombre,
      },
    };
    const requestConfig = this.createRequestContactConfig(contactId, data);
    await axios(requestConfig);
  }

  async assignUserRegisteredLabel(conversationId: number) {
    const data = { labels: ['cliente-registrado'] };
    const requestConfig = this.assignRegisteredUserLabelConfig(
      conversationId,
      data,
    );
    await axios(requestConfig);
  }

  async getMessagesFromConversation(conversationId: number): Promise<any> {
    const requestConfig = {
      baseURL: this.CHATWOOT_API_URL,
      method: 'get',
      url: `${this.CHATWOOT_ACCOUNT_ID}/conversations/${conversationId}/messages`,
      headers: {
        'Content-Type': 'application/json',
        api_access_token: this.CHATWOOT_API_ACCESS_TOKEN,
      },
    };
    const response = await axios(requestConfig);
    return response.data;
  }

  async derivateConversation(
    conversationId: number,
  ): Promise<AgentDerivationResponse> {
    try {
      const requestConfig = {
        baseURL: this.CHATWOOT_API_URL,
        method: 'post',
        url: `${this.CHATWOOT_ACCOUNT_ID}/conversations/${conversationId}/assignments`,
        headers: {
          'Content-Type': 'application/json',
          api_access_token: this.CHATWOOT_API_ACCESS_TOKEN,
        },
        data: {
          // TODO: Cambiar el assignee_id a la ID del agente que se va a derivar
          assignee_id: 4,
        },
      };
      const response = await axios(requestConfig);
      return response.data;
    } catch (error) {
      console.log(error);
      throw new Error('Error al derivar la conversación');
    }
  }

  async updateSupprtCustomAttribute(contactId: number, support: boolean) {
    const data = {
      custom_attributes: { support: support },
    };
    const requestConfig = this.updateSupportCustomAttributeConfig(
      contactId,
      data,
    );
    await axios(requestConfig);
  }

  private updateSupportCustomAttributeConfig(
    contactId: number,
    data: object,
  ): AxiosRequestConfig {
    return {
      baseURL: this.CHATWOOT_API_URL,
      method: 'put',
      url: `${this.CHATWOOT_ACCOUNT_ID}/contacts/${contactId}`,
      headers: {
        'Content-Type': 'application/json',
        api_access_token: this.CHATWOOT_API_ACCESS_TOKEN,
      },
      data,
    };
  }
}

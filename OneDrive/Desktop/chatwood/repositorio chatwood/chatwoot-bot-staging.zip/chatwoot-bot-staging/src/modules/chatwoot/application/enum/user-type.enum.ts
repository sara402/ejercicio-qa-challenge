export enum UserType {
  USER = 'user',
  ASSISTANT = 'assistant',
  SYSTEM = 'system',
}

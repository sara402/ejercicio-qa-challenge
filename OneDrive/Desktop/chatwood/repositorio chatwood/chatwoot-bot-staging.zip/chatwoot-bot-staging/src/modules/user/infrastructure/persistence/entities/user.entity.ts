import { Base } from '@/common/infrastructure/entities/base.entity';
import { TokensEntity } from '@/modules/tokens/infrastructure/persistence/entities/tokens.entity';
import { TransactionsEntity } from '@/modules/transactions/infrastructure/persistence/entities/transactions.entity';
import { Entity, Column, OneToOne, JoinColumn, OneToMany } from 'typeorm';
@Entity({ name: 'user' })
export class UserEntity extends Base {
  @Column()
  externalId: string;

  @Column()
  name: string;

  @Column()
  username: string;

  @Column()
  password: string;

  @Column()
  phone: string;

  @Column({ name: 'conversation_id' })
  conversationId: number;

  @Column({ name: 'ai_register_id' })
  aiRegisterId: string;

  @OneToOne(() => TokensEntity, (tokens) => tokens.user, {
    cascade: true,
    onDelete: 'CASCADE',
    eager: true,
  })
  @JoinColumn({ name: 'tokens_id' })
  tokens: TokensEntity;

  @OneToMany(() => TransactionsEntity, (transactions) => transactions.user)
  transactions: TransactionsEntity[];
}

import { InjectRepository } from '@nestjs/typeorm';

import { Repository } from 'typeorm';
import { PaymentMethodsEntity } from './persistence/entities/payment-methods.entity';
import { IPaymentMethodsRepository } from '../application/interface/payment-methods.repository.interface';
import { PaymentMethodsDomain } from '../domain/payment-methods.domain';
import { Injectable, InternalServerErrorException } from '@nestjs/common';

@Injectable()
export class PaymentMethodsPostgreSQLRepository
  implements IPaymentMethodsRepository
{
  constructor(
    @InjectRepository(PaymentMethodsEntity, process.env.DB_NAME)
    private readonly paymentMethodsRepository: Repository<PaymentMethodsEntity>,
  ) {}

  async findAll(): Promise<PaymentMethodsEntity[]> {
    try {
      return this.paymentMethodsRepository.find();
    } catch (error) {
      throw new InternalServerErrorException(
        'Failed to find all payment methods',
      );
    }
  }

  async findById(id: number): Promise<PaymentMethodsEntity> {
    try {
      return this.paymentMethodsRepository.findOne({ where: { id } });
    } catch (error) {
      throw new InternalServerErrorException(
        'Failed to find payment method by id',
      );
    }
  }

  async create(
    paymentMethods: PaymentMethodsDomain,
  ): Promise<PaymentMethodsEntity> {
    try {
      const paymentMethodsEntity =
        this.paymentMethodsRepository.create(paymentMethods);
      return await this.paymentMethodsRepository.save(paymentMethodsEntity);
    } catch (error) {
      throw new InternalServerErrorException('Failed to create payment method');
    }
  }

  async update(
    id: number,
    paymentMethods: PaymentMethodsDomain,
  ): Promise<PaymentMethodsEntity> {
    try {
      const paymentMethodsUpdate = await this.paymentMethodsRepository.preload({
        id,
        ...paymentMethods,
      });

      if (!paymentMethodsUpdate) {
        throw new Error(`payment method #${id} do not exist`);
      }

      return await this.paymentMethodsRepository.save(paymentMethodsUpdate);
    } catch (error) {
      throw new InternalServerErrorException('Failed to update payment method');
    }
  }

  async delete(id: number): Promise<void> {
    try {
      await this.paymentMethodsRepository.delete(id);
    } catch (error) {
      throw new InternalServerErrorException('Failed to delete payment method');
    }
  }
}

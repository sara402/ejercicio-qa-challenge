import { TransactionDomain } from '@/modules/transactions/domain/transaction.domain';
import { PaymentMethodsDomain } from '@/modules/payment-methods/domain/payment-methods.domain';
import { PreferenceStatus } from '@/modules/mp/application/enum/preference-status.enum';
export function transactionDomainMapper(
  amount: number,
  userId: number,
  paymentMethod: PaymentMethodsDomain,
) {
  console.log(paymentMethod);
  const transactionDomain = new TransactionDomain();
  transactionDomain.amount = amount;
  transactionDomain.userId = userId;
  transactionDomain.status = PreferenceStatus.PENDING;
  transactionDomain.paymentMethod = paymentMethod;
  return transactionDomain;
}

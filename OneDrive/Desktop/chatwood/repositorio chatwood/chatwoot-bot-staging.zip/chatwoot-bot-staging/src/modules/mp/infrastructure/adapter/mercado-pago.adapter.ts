import { Injectable } from '@nestjs/common';
import axios from 'axios';
import { v4 as uuidv4 } from 'uuid';
import { PreferenceCreateData } from 'mercadopago/dist/clients/preference/create/types';
import { PreferenceResponse } from 'mercadopago/dist/clients/preference/commonTypes';
import { PaymentCheckStatusResponse } from '../../application/interface/payment-check-status-response.interface';
import { Payment, Preference } from 'mercadopago';
import MercadoPagoConfig from 'mercadopago';
import { PaymentResponse } from 'mercadopago/dist/clients/payment/commonTypes';

@Injectable()
export class MercadoPagoAdapter {
  constructor() {}

  async createPayment(
    preferenceData: PreferenceCreateData,
  ): Promise<PreferenceResponse> {
    try {
      const client = new MercadoPagoConfig({
        accessToken: process.env.MERCADO_PAGO_ACCESS_TOKEN,
        options: {
          timeout: 5000,
          idempotencyKey: this.generateIdempotencyKey(),
        },
      });

      const preference = new Preference(client);
      return await preference.create(preferenceData);
    } catch (error: any) {
      console.log(error);
      throw new Error(`Failed to create payment link: ${error.message}`);
    }
  }

  async getPreferenceById(paymentId: number): Promise<PaymentResponse> {
    try {
      const client = new MercadoPagoConfig({
        accessToken: process.env.MERCADO_PAGO_ACCESS_TOKEN,
        options: {
          timeout: 5000,
          idempotencyKey: this.generateIdempotencyKey(),
        },
      });

      const payment = new Payment(client);
      return await payment.get({ id: paymentId });
    } catch (error) {
      console.log(error);
      throw new Error(`Failed to get payment details: ${error.message}`);
    }
  }

  async getPaymentStatus(
    paymentId: number,
  ): Promise<PaymentCheckStatusResponse> {
    try {
      const headers = {
        Authorization: `Bearer ${process.env.MERCADO_PAGO_ACCESS_TOKEN}`,
        'Content-Type': 'application/json',
      };

      const { data } = await axios.get(
        `https://api.mercadopago.com/v1/payments/${paymentId}`,
        { headers },
      );

      return {
        status: data.status,
        externalReference: data.external_reference,
      };
    } catch (error) {
      console.log(error);
      throw new Error(`Failed to get payment status: ${error.message}`);
    }
  }

  private generateIdempotencyKey(): string {
    return `${Date.now()}-${uuidv4()}`;
  }
}

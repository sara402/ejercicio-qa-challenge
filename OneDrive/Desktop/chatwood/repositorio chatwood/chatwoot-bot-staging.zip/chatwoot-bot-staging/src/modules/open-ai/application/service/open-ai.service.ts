import { Injectable } from '@nestjs/common';
import { getSystemMessage } from '../utils/openai.utils';
import {
  frequencyPenalty,
  maxCompletionTokens,
  openAIModel,
  presencePenalty,
  responseFormat,
  temperature,
  topP,
} from '../constants/openai.constants';
import { OpenAiAdapter } from '../../infrastructure/adapter/openai.adapter';
import OpenAI from 'openai';
import { ChatCompletionMessageParam } from 'openai/resources';

@Injectable()
export class OpenAiService {
  constructor(private readonly openAiAdapter: OpenAiAdapter) {}

  async newMessageFromUserOpenAIChat(
    inputMessage: ChatCompletionMessageParam[],
    username?: string,
    nombre?: string,
  ) {
    const openAiObject: OpenAI.Chat.ChatCompletionCreateParams = {
      model: openAIModel,
      messages: [getSystemMessage(username, nombre), ...inputMessage],
      response_format: responseFormat,
      tools: [
        {
          type: 'function',
          function: {
            name: 'create_user',
            description: 'Creates a new user in the system',
            parameters: {
              type: 'object',
              required: ['full_name'],
              properties: {
                full_name: {
                  type: 'string',
                  description: 'Nombre completo',
                },
              },
              additionalProperties: false,
            },
            strict: true,
          },
        },
        {
          type: 'function',
          function: {
            name: 'create_payment_link',
            description: 'Crea un link de pago',
            parameters: {
              type: 'object',
              required: ['name', 'lastName', 'amount', 'username'],
              properties: {
                name: {
                  type: 'string',
                  description: 'Nombre del usuario',
                },
                lastName: {
                  type: 'string',
                  description: 'Apellido del usuario',
                },
                amount: {
                  type: 'number',
                  description: 'Monto del pago',
                },
                username: {
                  type: 'string',
                  description: 'Nombre de usuario',
                },
              },
              additionalProperties: false,
            },
            strict: true,
          },
        },
        {
          type: 'function',
          function: {
            name: 'get_user',
            description: 'Obtiene información del usuario',
            parameters: {
              type: 'object',
              required: ['username'],
              properties: {
                username: {
                  type: 'string',
                  description: 'Nombre de usuario',
                },
              },
              additionalProperties: false,
            },
            strict: true,
          },
        },
        {
          type: 'function',
          function: {
            name: 'derivate_conversation',
            description: 'Deriva la conversación a un agente especializado',
          },
        },
      ],
      temperature,
      max_tokens: maxCompletionTokens,
      top_p: topP,
      frequency_penalty: frequencyPenalty,
      presence_penalty: presencePenalty,
      store: true,
    };

    const {
      choices: [{ message: openAIResponse }],
    } = await this.openAiAdapter.newConversation(openAiObject);

    return openAIResponse;
  }
}

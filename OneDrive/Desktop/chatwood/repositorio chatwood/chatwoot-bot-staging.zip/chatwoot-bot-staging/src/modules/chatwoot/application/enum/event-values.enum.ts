export enum EventValues {
  CONVERSATION_CREATED = 'automation_event.conversation_created',
  MESSAGE_CREATED = 'automation_event.message_created',
}

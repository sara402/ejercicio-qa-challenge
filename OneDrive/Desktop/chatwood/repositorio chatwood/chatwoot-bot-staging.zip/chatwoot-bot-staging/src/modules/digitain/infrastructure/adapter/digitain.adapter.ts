import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import axios, { AxiosRequestConfig } from 'axios';
import { createHash } from 'crypto';
import { DigitainDomain } from '../../domain/digitain.domain';
import { CreateUserDigitainResponse } from '../../application/dto/response/create-user.digitain.response';
import { GetPlayerDigitainResponse } from '../../application/dto/response/get-player.digitain.response';

@Injectable()
export class DigitainAdapter {
  private readonly DIGITAIN_SECRET: string;
  private readonly DIGITAIN_API_URL: string;
  private readonly DIGITAIN_CREATE_USER_URL: string;
  private readonly DIGITAIN_DEPOSIT_URL: string;
  private readonly PROJECT_ID: string;
  private readonly DIGITAIN_GET_USER_URL: string;

  constructor(private readonly environmentConfig: ConfigService) {
    this.DIGITAIN_SECRET = this.environmentConfig.get('digitain.secret');
    this.DIGITAIN_API_URL = this.environmentConfig.get('digitain.apiUrl');
    this.DIGITAIN_CREATE_USER_URL = this.environmentConfig.get(
      'digitain.createUserUrl',
    );
    this.DIGITAIN_DEPOSIT_URL = this.environmentConfig.get(
      'digitain.depositUrl',
    );
    this.PROJECT_ID = this.environmentConfig.get('digitain.projectId');
    this.DIGITAIN_GET_USER_URL = this.environmentConfig.get(
      'digitain.getUserUrl',
    );
  }

  private generateAuthToken(): string {
    const date = new Date();
    const day = String(date.getUTCDate()).padStart(2, '0');
    const month = String(date.getUTCMonth() + 1).padStart(2, '0');
    const year = date.getUTCFullYear();

    const token = `${day}${month}${year}${this.DIGITAIN_SECRET}`;
    return createHash('md5').update(token).digest('hex');
  }

  private createRequestConfig(data: object, url: string): AxiosRequestConfig {
    const authToken = this.generateAuthToken();
    return {
      baseURL: this.DIGITAIN_API_URL,
      method: 'post',
      url: `${url}`,
      headers: {
        'Content-Type': 'application/json',
        Authorization: authToken,
        'Integration-Environment': 1,
      },
      data,
    };
  }

  private createRequestConfigGet(url: string): AxiosRequestConfig {
    const authToken = this.generateAuthToken();
    return {
      baseURL: this.DIGITAIN_API_URL,
      method: 'get',
      url: `${url}`,
      headers: {
        'Content-Type': 'application/json',
        Authorization: authToken,
        'Integration-Environment': 1,
      },
    };
  }

  async createUser(user: DigitainDomain): Promise<CreateUserDigitainResponse> {
    try {
      const requestConfig = this.createRequestConfig(
        {
          projectId: this.PROJECT_ID,
          ...user,
          agentId: 1,
          currencyCode: 'ARS',
        },
        this.DIGITAIN_CREATE_USER_URL,
      );
      const response = await axios.request(requestConfig);
      return {
        Message: response.data.Message,
        ResultCode: response.data.ResultCode,
        Value: response.data.Value,
      };
    } catch (error) {
      console.log(error);
      throw new Error(
        `Error al crear usuario en Digitain: ${error.response.data.Message}`,
      );
    }
  }

  async deposit(object: object): Promise<void> {
    try {
      const requestConfig = this.createRequestConfig(
        {
          projectId: this.PROJECT_ID,
          ...object,
          currencyCode: 'ARS',
        },
        this.DIGITAIN_DEPOSIT_URL,
      );
      await axios.request(requestConfig);
    } catch (error) {
      throw new Error(
        `Error al depositar en Digitain: ${error.response.data.Message}`,
      );
    }
  }

  async getUserByUsername(
    username: string,
  ): Promise<GetPlayerDigitainResponse> {
    try {
      const requestConfig = this.createRequestConfigGet(
        `${this.DIGITAIN_GET_USER_URL}?projectId=${this.PROJECT_ID}&userName=${username}`,
      );
      const response = await axios.request(requestConfig);
      return response.data;
    } catch (error) {
      throw new Error(
        `Error al obtener usuario en Digitain: ${error.response.data.Message}`,
      );
    }
  }
}

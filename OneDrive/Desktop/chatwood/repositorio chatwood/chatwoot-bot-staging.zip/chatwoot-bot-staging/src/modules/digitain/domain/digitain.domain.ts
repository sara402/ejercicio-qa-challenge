export class DigitainDomain {
  externalId?: string;
  firstName: string;
  lastName: string;
  mobile: string;
  email: string;
  password: string;
  userName: string;
}

export interface PaymentCheckStatusResponse {
  status: string;
  externalReference: string;
}

import { Module } from '@nestjs/common';
import { PaymentMethodsService } from './application/service/payment-methods.service';
import { PAYMENT_METHODS_REPOSITORY } from './application/interface/payment-methods.repository.interface';
import { PaymentMethodsEntity } from './infrastucture/persistence/entities/payment-methods.entity';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PaymentMethodsPostgreSQLRepository } from './infrastucture/payment-methods.postgresql.repository';
@Module({
  imports: [
    TypeOrmModule.forFeature([PaymentMethodsEntity], process.env.DB_NAME),
  ],
  providers: [
    PaymentMethodsService,
    {
      provide: PAYMENT_METHODS_REPOSITORY,
      useClass: PaymentMethodsPostgreSQLRepository,
    },
  ],
  exports: [PaymentMethodsService],
})
export class PaymentMethodsModule {}

import { HttpException, HttpStatus, Inject, Injectable } from '@nestjs/common';
import {
  IUserRepository,
  USER_REPOSITORY,
} from '../interface/user.repository.interface';
import { MapperService } from '@/common/application/mapper/mapper.service';
import { UserDomain } from '../../domain/user.domain';
import * as bcrypt from 'bcrypt';
import { TokensDomain } from '@/modules/tokens/domain/tokens.domain';
import { DigitainService } from '@/modules/digitain/application/service/digitain.service';
import { ConfigService } from '@nestjs/config';
import { GetPlayerDigitainResponse } from '@/modules/digitain/application/dto/response/get-player.digitain.response';
@Injectable()
export class UserService {
  private readonly EMAIL_DOMAIN: string;
  constructor(
    @Inject(USER_REPOSITORY)
    private readonly userRepository: IUserRepository,
    private readonly mapperService: MapperService,
    private readonly digitainService: DigitainService,
    private readonly environmentConfig: ConfigService,
  ) {
    this.EMAIL_DOMAIN = this.environmentConfig.get('digitain.emailDomain');
  }

  async getUserById(id: number): Promise<UserDomain> {
    try {
      const user = await this.userRepository.getUserById(id);

      if (!user) {
        throw new Error('User not found');
      }

      return this.mapperService.entityToClass(user, new UserDomain());
    } catch (e) {
      throw new HttpException(e.message, HttpStatus.NOT_FOUND);
    }
  }

  async getAllUsers(): Promise<UserDomain[]> {
    try {
      const users = await this.userRepository.getAllUsers();

      return users.map((client) =>
        this.mapperService.entityToClass(client, new UserDomain()),
      );
    } catch (e) {
      throw new HttpException(e.message, HttpStatus.NOT_FOUND);
    }
  }

  async getUserByUsername(username: string): Promise<UserDomain> {
    try {
      return await this.userRepository.getUserByUsername(username);
    } catch (e) {
      return null;
    }
  }

  async getUserByPhone(phone: string): Promise<UserDomain> {
    return await this.userRepository.getUserByPhone(phone);
  }

  async getUserByAiRegisterId(aiRegisterId: string): Promise<UserDomain> {
    return await this.userRepository.getUserByAiRegisterId(aiRegisterId);
  }

  async registerUser(
    name: string,
    phoneNumber: string,
    aiRegisterId: string,
    conversationId: number,
  ): Promise<UserDomain> {
    try {
      const userPhoneRegistered = await this.getUserByPhone(phoneNumber);

      if (userPhoneRegistered) {
        throw new Error(
          `El numero de telefono ${phoneNumber} ya esta registrado, su usuario es ${userPhoneRegistered.username}`,
        );
      }

      let username = this.formatUsername(name, phoneNumber);
      let password = this.formatPassword(name, phoneNumber);
      let formattedPhone = phoneNumber;
      const isUserRegistered = await this.getUserByUsername(username);

      if (isUserRegistered) {
        throw new Error(
          `El usuario ${username} ya existe, intente con otro numero de telefono`,
        );
      }
      const [firstName, lastName] = name.split(' ');
      const userDigitain = await this.digitainService.createUser({
        firstName,
        lastName,
        mobile: phoneNumber,
        password,
        email: `${username}@${this.EMAIL_DOMAIN}`,
        userName: username,
      });

      const passwordHashed = await this.hashPassword(password);

      const tokensDomain = this.mapperService.dtoToClass(
        {
          balance: 0,
          withdrawableBalance: 0,
        },
        new TokensDomain(),
      );

      const userDomain = this.mapperService.dtoToClass(
        {
          externalId: userDigitain.externalId,
          name,
          username,
          password: passwordHashed,
          phone: formattedPhone,
          tokens: tokensDomain,
          conversationId,
          aiRegisterId,
        },
        new UserDomain(),
      );

      await this.userRepository.create(userDomain);

      return { ...userDomain, password };
    } catch (e) {
      throw new Error(e.message);
    }
  }

  async registerUserFromDigitain(
    userDigitain: GetPlayerDigitainResponse,
    conversationId: number,
    tool_call_id: string,
  ): Promise<UserDomain> {
    try {
      const userPhoneRegistered = await this.getUserByPhone(
        userDigitain.Value.Mobile,
      );

      if (userPhoneRegistered) {
        throw new Error(
          `El numero de telefono ${userDigitain.Value.Mobile} ya esta registrado, su usuario es ${userPhoneRegistered.username}`,
        );
      }
      const isUserRegistered = await this.getUserByUsername(
        userDigitain.Value.UserName,
      );
      if (isUserRegistered) {
        throw new Error(
          `El usuario ${userDigitain.Value.UserName} ya existe, intente con otro numero de telefono`,
        );
      }

      let password = this.formatPassword(
        userDigitain.Value.FirstName + ' ' + userDigitain.Value.LastName,
        userDigitain.Value.Mobile,
      );

      const passwordHashed = await this.hashPassword(password);

      const tokensDomain = this.mapperService.dtoToClass(
        {
          balance: userDigitain.Value.Balance,
          withdrawableBalance: userDigitain.Value.WithdrawableBalance,
        },
        new TokensDomain(),
      );

      const userDomain = this.mapperService.dtoToClass(
        {
          externalId: userDigitain.Value.Id,
          name:
            userDigitain.Value.FirstName + ' ' + userDigitain.Value.LastName,
          username: userDigitain.Value.UserName,
          password: passwordHashed,
          phone: userDigitain.Value.Mobile,
          tokens: tokensDomain,
          aiRegisterId: tool_call_id,
          conversationId,
        },
        new UserDomain(),
      );

      await this.userRepository.create(userDomain);

      return { ...userDomain, password };
    } catch (e) {
      throw new Error(e.message);
    }
  }

  async update(
    userId: number,
    updatedUserInformation: Partial<UserDomain>,
  ): Promise<UserDomain> {
    try {
      await this.getUserById(userId);

      return await this.userRepository.update(userId, updatedUserInformation);
    } catch (e) {
      throw new HttpException(e.message, HttpStatus.BAD_REQUEST);
    }
  }

  async delete(id: number): Promise<void> {
    try {
      await this.getUserById(id);

      return await this.userRepository.delete(id);
    } catch (e) {
      throw new HttpException(e.message, HttpStatus.BAD_REQUEST);
    }
  }

  private async hashPassword(password: string): Promise<string> {
    return await await bcrypt.hash(password, 10);
  }

  private formatUsername(name: string, phoneNumber: string): string {
    return (
      name.toLowerCase().replace(/\s+/g, '').trim() + phoneNumber.slice(-4)
    );
  }

  private formatPassword(name: string, phoneNumber: string): string {
    
    return (
      phoneNumber.slice(-4) + name.toLowerCase().replace(/\s+/g, '').trim()
    );
  }
}

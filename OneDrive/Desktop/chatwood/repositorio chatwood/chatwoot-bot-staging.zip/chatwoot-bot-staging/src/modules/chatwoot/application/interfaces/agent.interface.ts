export interface AgentDerivationResponse {
  id: number;
  accountId: number;
  availabilityStatus: 'online' | 'offline' | 'busy';
  autoOffline: boolean;
  confirmed: boolean;
  email: string;
  availableName: string;
  name: string;
  role: 'agent' | 'administrator';
  thumbnail: string;
  customRoleId: number | null;
}

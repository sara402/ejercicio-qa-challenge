import { MercadoPagoDomain } from '../../domain/mercado-pago.domain';
import { MercadoPagoEntity } from '../../infrastructure/persistence/entities/mercado-pago.entity';

export const MERCADO_PAGO_REPOSITORY = 'MERCADO_PAGO_REPOSITORY';

export interface IMercadoPagoRepository {
  create(mercadoPagoInformation: MercadoPagoDomain): Promise<MercadoPagoEntity>;
  findById(id: number): Promise<MercadoPagoEntity>;
  getPreferenceByPreferenceId(id: string): Promise<MercadoPagoEntity>;
  getPreferenceByExternalReference(
    externalReference: string,
  ): Promise<MercadoPagoEntity>;
  update(
    id: number,
    data: Partial<MercadoPagoDomain>,
  ): Promise<MercadoPagoEntity>;
  delete(id: number): Promise<void>;
}

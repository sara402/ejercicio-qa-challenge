import { TokensDomain } from '@/modules/tokens/domain/tokens.domain';
import { UserDomain } from '../../domain/user.domain';

export function userDomainMapper(
  externalId: string,
  name: string,
  username: string,
  password: string,
  phone: string,
  tokens: TokensDomain,
): UserDomain {
  const user = new UserDomain();
  user.externalId = externalId;
  user.name = name;
  user.username = username;
  user.password = password;
  user.phone = phone;
  user.tokens = tokens;
  return user;
}

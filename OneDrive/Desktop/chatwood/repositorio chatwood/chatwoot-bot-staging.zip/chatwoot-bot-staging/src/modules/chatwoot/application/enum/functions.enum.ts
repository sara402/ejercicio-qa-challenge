export enum FunctionsEnum {
  CREATE_USER = 'create_user',
  GET_USER = 'get_user',
  CREATE_PAYMENT_LINK = 'create_payment_link',
  DERIVATE_CONVERSATION = 'derivate_conversation',
}

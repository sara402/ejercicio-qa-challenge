export class AdditionalAttributesDTO {
  browser: {
    device_name: string;
    browser_name: string;
    platform_name: string;
    browser_version: string;
    platform_version: string;
  };
  referer: string;
  initiated_at: {
    timestamp: string;
  };
  browser_language: string;
}

export class ContactInboxDTO {
  id: number;
  contact_id: number;
  inbox_id: number;
  source_id: string;
  created_at: string;
  updated_at: string;
  hmac_verified: boolean;
  pubsub_token: string;
}

export class MessageDTO {
  id: number;
  content: string;
  account_id: number;
  inbox_id: number;
  conversation_id: number;
  message_type: number;
  created_at: number;
  updated_at: string;
  private: boolean;
  status: string;
  source_id: string | null;
  content_type: string;
  content_attributes: {
    in_reply_to: string | null;
  };
  sender_type: string;
  sender_id: number;
  external_source_ids: object;
  additional_attributes: object;
  processed_message_content: string;
  sentiment: object;
  conversation: {
    assignee_id: number;
    unread_count: number;
    last_activity_at: number;
    contact_inbox: {
      source_id: string;
    };
  };
  sender: {
    additional_attributes: object;
    custom_attributes: object;
    email: string | null;
    id: number;
    identifier: string | null;
    name: string;
    phone_number: string;
    thumbnail: string;
    type: string;
  };
}

export class MetaDTO {
  sender: {
    additional_attributes: object;
    custom_attributes: {
      id_registro_ai: string;
      username: string;
      nombre: string;
    };
    email: string | null;
    id: number;
    identifier: string | null;
    name: string;
    phone_number: string;
    thumbnail: string;
    type: string;
  };
  assignee: {
    id: number;
    name: string;
    available_name: string;
    avatar_url: string;
    type: string;
    availability_status: string | null;
    thumbnail: string;
  };
  team: any;
  hmac_verified: boolean;
}

export class ConversationDTO {
  additional_attributes: AdditionalAttributesDTO;
  can_reply: boolean;
  channel: string;
  contact_inbox: ContactInboxDTO;
  id: number;
  inbox_id: number;
  messages: MessageDTO[];
  labels: string[];
  meta: MetaDTO;
  status: string;
  custom_attributes: object;
  snoozed_until: string | null;
  unread_count: number;
  first_reply_created_at: string | null;
  priority: string | null;
  waiting_since: number;
  agent_last_seen_at: number;
  contact_last_seen_at: number;
  last_activity_at: number;
  timestamp: number;
  created_at: number;
  event: string;
}

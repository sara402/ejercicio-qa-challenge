export class GetPlayerDigitainResponse {
  Message: string;
  ResultCode: number;
  Value: {
    Id: string;
    Balance: number;
    WithdrawableBalance: number;
    UserName: string;
    Email: string;
    Mobile: string;
    Gender: number;
    FirstName: string;
    LastName: string;
    LastLoginDate: string | null;
    Status: number;
    StatusName: string;
    RegistrationDate: string;
    LastLoginIP: string | null;
    Documents: any[];
  };
}

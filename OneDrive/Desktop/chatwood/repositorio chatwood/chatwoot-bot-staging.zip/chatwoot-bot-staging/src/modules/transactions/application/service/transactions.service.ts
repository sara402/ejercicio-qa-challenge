import { Injectable, BadRequestException } from '@nestjs/common';
import { Inject } from '@nestjs/common';
import {
  ITransactionsRepository,
  TRANSACTIONS_REPOSITORY,
} from '../interface/transactions.repository.interface';
import { TransactionDomain } from '../../domain/transaction.domain';
@Injectable()
export class TransactionsService {
  constructor(
    @Inject(TRANSACTIONS_REPOSITORY)
    private readonly transactionsRepository: ITransactionsRepository,
  ) {}

  async createTransaction(
    transaction: TransactionDomain,
  ): Promise<TransactionDomain> {
    return await this.transactionsRepository.createTransaction(transaction);
  }

  async getTransactionByPaymentMethodId(
    paymentMethodId: number,
  ): Promise<TransactionDomain> {
    return await this.transactionsRepository.getTransactionByPaymentMethodId(
      paymentMethodId,
    );
  }

  async getLastTransactionByUserId(userId: number): Promise<TransactionDomain> {
    if (!userId || userId <= 0) {
      throw new BadRequestException(
        'El ID de usuario debe ser un número válido mayor a 0',
      );
    }

    return await this.transactionsRepository.getLastTransactionByUserId(userId);
  }

  async updatePayment(
    id: number,
    data: Partial<TransactionDomain>,
  ): Promise<TransactionDomain> {
    return this.transactionsRepository.update(id, data);
  }
}

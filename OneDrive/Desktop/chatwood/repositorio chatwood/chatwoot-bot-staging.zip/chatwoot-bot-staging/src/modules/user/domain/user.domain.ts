import { Base } from '@/common/domain/base.domain';
import { TokensDomain } from '@/modules/tokens/domain/tokens.domain';

export class UserDomain extends Base {
  externalId: string;
  name: string;
  username: string;
  password: string;
  phone: string;
  aiRegisterId: string;
  conversationId: number;
  tokens: TokensDomain;
}

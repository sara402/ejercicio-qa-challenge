export interface BrowserAttributes {
  device_name: string;
  browser_name: string;
  platform_name: string;
  browser_version: string;
  platform_version: string;
}

export interface InitiatedAt {
  timestamp: string;
}

export interface AdditionalAttributes {
  browser: BrowserAttributes;
  referer: string;
  initiated_at: InitiatedAt;
  browser_language: string;
}

export interface ContactInbox {
  id: number;
  contact_id: number;
  inbox_id: number;
  source_id: string;
  created_at: string;
  updated_at: string;
  hmac_verified: boolean;
  pubsub_token: string;
}

export interface Message {
  id: number;
  content: string;
  account_id: number;
  inbox_id: number;
  conversation_id: number;
  message_type: number;
  created_at: number;
  updated_at: string;
  private: boolean;
  status: string;
  source_id: null | string;
  content_type: string;
  content_attributes: Record<string, any>;
  sender_type: string;
  sender_id: number;
  external_source_ids: Record<string, any>;
  additional_attributes: Record<string, any>;
  processed_message_content: string;
  sentiment: Record<string, any>;
  conversation: Record<string, any>;
  sender: Record<string, any>;
}

export interface Sender {
  additional_attributes: Record<string, any>;
  custom_attributes: Record<string, any>;
  email: null | string;
  id: number;
  identifier: null | string;
  name: string;
  phone_number: string;
  thumbnail: string;
  type: string;
}

export interface Assignee {
  id: number;
  name: string;
  available_name: string;
  avatar_url: string;
  type: string;
  availability_status: null | string;
  thumbnail: string;
}

export interface Meta {
  sender: Sender;
  assignee: Assignee;
  team: null | Record<string, any>;
  hmac_verified: boolean;
}

export interface MessageJob {
  additional_attributes: AdditionalAttributes;
  can_reply: boolean;
  channel: string;
  contact_inbox: ContactInbox;
  id: number;
  inbox_id: number;
  messages: Message[];
  labels: string[];
  meta: Meta;
  status: string;
  custom_attributes: Record<string, any>;
  snoozed_until: null | string;
  unread_count: number;
  first_reply_created_at: string;
  priority: null | number;
  waiting_since: number;
  agent_last_seen_at: number;
  contact_last_seen_at: number;
  last_activity_at: number;
  timestamp: number;
  created_at: number;
  event: string;
}

import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { TransactionsEntity } from './entities/transactions.entity';
import { Injectable } from '@nestjs/common';
import { ITransactionsRepository } from '../../application/interface/transactions.repository.interface';
import { TransactionDomain } from '../../domain/transaction.domain';

@Injectable()
export class TransactionsPostgreSQLRepository
  implements ITransactionsRepository
{
  constructor(
    @InjectRepository(TransactionsEntity, process.env.DB_NAME)
    private readonly transactionsRepository: Repository<TransactionsEntity>,
  ) {}

  async createTransaction(
    transaction: TransactionDomain,
  ): Promise<TransactionsEntity> {
    try {
      const transactionEntity = this.transactionsRepository.create(transaction);
      return await this.transactionsRepository.save(transactionEntity);
    } catch (error) {
      throw new Error(error.message);
    }
  }

  async getTransactionByPaymentMethodId(
    paymentMethodId: number,
  ): Promise<TransactionsEntity> {
    return await this.transactionsRepository.findOne({
      where: { paymentMethod: { id: paymentMethodId } },
      relations: ['paymentMethod'],
    });
  }

  async getLastTransactionByUserId(
    userId: number,
  ): Promise<TransactionsEntity> {
    return await this.transactionsRepository.findOne({
      where: { userId: userId },
      relations: ['paymentMethod'],
      order: { createdAt: 'DESC' },
    });
  }
  async update(
    id: number,
    data: Partial<TransactionDomain>,
  ): Promise<TransactionDomain> {
    try {
      const transactionUpdate = await this.transactionsRepository.preload({
        id,
        ...data,
      });

      if (!transactionUpdate) {
        throw new Error(`transaction #${id} do not exist`);
      }

      return await this.transactionsRepository.save(transactionUpdate);
    } catch (e) {
      throw new Error(e.message);
    }
  }
}

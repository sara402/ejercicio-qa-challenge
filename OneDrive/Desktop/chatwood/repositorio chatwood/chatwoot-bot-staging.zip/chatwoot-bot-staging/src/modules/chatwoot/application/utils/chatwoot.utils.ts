import { ConversationDTO } from '../dto/conversation.dto';

export function destructureElementsFromChatwoot(req: ConversationDTO) {
  const inboxId = req.inbox_id;
  const { messages, event } = req;
  if (!messages || !messages[0]) {
    throw new Error("El objeto 'messages' no está definido o está vacío.");
  }

  const { account_id: accountId, conversation_id: conversationId } =
    messages[0];
  const phoneNumber = req.meta.sender.phone_number;
  const username = req.meta.sender.custom_attributes?.username;
  const nombre = req.meta.sender.custom_attributes?.nombre;
  const contactId = req.contact_inbox.contact_id;

  return {
    inboxId,
    accountId,
    conversationId,
    event,
    contactId,
    messages,
    phoneNumber,
    username,
    nombre,
  };
}

interface MessagePayload {
  sender: {
    type?: 'contact' | 'assistant' | 'system';
  };
  content: string;
}

export function mapMessages(payload: MessagePayload[]): any[] {
  return payload
    .map((message) => {
      if (message.sender) {
        const role = message.sender.type === 'contact' ? 'user' : 'assistant';
        return {
          role,
          content: message.content,
        };
      }
    })
    .filter(Boolean);
}

import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { TokensDomain } from '../../domain/tokens.domain';
import { ITokensRepository } from '../../application/interface/tokens.repository.interface';
import { TokensEntity } from './entities/tokens.entity';

@Injectable()
export class TokensPostgreSQLRepository implements ITokensRepository {
  constructor(
    @InjectRepository(TokensEntity, process.env.DB_NAME)
    private readonly tokensRepository: Repository<TokensEntity>,
  ) {}

  async getTokensById(id: number): Promise<TokensEntity> {
    try {
      return this.tokensRepository.findOne({ where: { id } });
    } catch (e) {
      throw new Error(e.message);
    }
  }

  async update(
    id: number,
    updatedTokenInformation: Partial<TokensDomain>,
  ): Promise<TokensEntity> {
    try {
      const updatedToken = await this.tokensRepository.preload({
        id,
        ...updatedTokenInformation,
      });

      if (!updatedToken) {
        throw new Error(`user #${id} do not exist`);
      }

      return await this.tokensRepository.save(updatedToken);
    } catch (e) {
      throw new Error(e.message);
    }
  }

  async delete(id: number): Promise<void> {
    try {
      await this.tokensRepository.softDelete(id);
    } catch (e) {
      throw new Error(e.message);
    }
  }
}

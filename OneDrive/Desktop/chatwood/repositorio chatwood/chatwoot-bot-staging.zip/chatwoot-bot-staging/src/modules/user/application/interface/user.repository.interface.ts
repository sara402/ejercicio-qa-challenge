import { UserDomain } from '../../domain/user.domain';
import { UserEntity } from '../../infrastructure/persistence/entities/user.entity';

export const USER_REPOSITORY = 'USER_REPOSITORY';

export interface IUserRepository {
  getAllUsers(): Promise<UserEntity[]>;
  getUserById(id: number): Promise<UserEntity>;
  getUserByUsername(username: string): Promise<UserEntity>;
  getUserByPhone(phone: string): Promise<UserEntity>;
  getUserByAiRegisterId(aiRegisterId: string): Promise<UserEntity>;
  create(userInformation: UserDomain): Promise<UserEntity>;
  update(
    id: number,
    updatedUserInformation: Partial<UserDomain>,
  ): Promise<UserEntity>;
  delete(id: number): Promise<void>;
}

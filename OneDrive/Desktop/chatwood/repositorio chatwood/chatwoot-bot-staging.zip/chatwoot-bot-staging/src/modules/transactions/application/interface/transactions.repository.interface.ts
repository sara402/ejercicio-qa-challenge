import { TransactionDomain } from '../../domain/transaction.domain';
import { TransactionsEntity } from '../../infrastructure/persistence/entities/transactions.entity';

export const TRANSACTIONS_REPOSITORY = 'TRANSACTIONS_REPOSITORY';

export interface ITransactionsRepository {
  createTransaction(
    transaction: TransactionDomain,
  ): Promise<TransactionsEntity>;
  getTransactionByPaymentMethodId(
    paymentMethodId: number,
  ): Promise<TransactionsEntity>;
  getLastTransactionByUserId(userId: number): Promise<TransactionsEntity>;
  update(
    id: number,
    data: Partial<TransactionDomain>,
  ): Promise<TransactionDomain>;
}

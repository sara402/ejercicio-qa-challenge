import { Injectable } from '@nestjs/common';
import { ConversationDTO } from '../dto/conversation.dto';
import { UserService } from '@/modules/user/application/service/user.service';
import {
  destructureElementsFromChatwoot,
  mapMessages,
} from '../utils/chatwoot.utils';
import { EventValues } from '../enum/event-values.enum';
import { ChatwootAdapter } from '../../infrastructure/adapter/chatwoot.adapter';
import { OpenAiService } from '@/modules/open-ai/application/service/open-ai.service';
import { UserType } from '../enum/user-type.enum';
import { FunctionsEnum } from '../enum/functions.enum';
import { DigitainService } from '@/modules/digitain/application/service/digitain.service';
import { MercadoPagoService } from '@/modules/mp/application/service/mercado-pago.service';
@Injectable()
export class ChatwootService {
  constructor(
    private readonly userService: UserService,
    private readonly chatwootAdapter: ChatwootAdapter,
    private readonly openAiservice: OpenAiService,
    private readonly digitainService: DigitainService,
    private readonly mercadoPagoService: MercadoPagoService,
  ) {}

  async newConversation(req: ConversationDTO): Promise<any> {
    const { conversationId, event } = destructureElementsFromChatwoot(req);

    if (event !== EventValues.CONVERSATION_CREATED) {
      return;
    }

    await this.chatwootAdapter.sendNewConversationMessage(conversationId);

    return req;
  }

  async newMessage(req: ConversationDTO): Promise<any> {
    const { conversationId, event, contactId, phoneNumber, username, nombre } =
      destructureElementsFromChatwoot(req);

    if (event !== EventValues.MESSAGE_CREATED) {
      return;
    }

    const chatwootMessages =
      await this.chatwootAdapter.getMessagesFromConversation(conversationId);

    const messages = mapMessages(chatwootMessages.payload);

    if (messages[messages.length - 1].role === UserType.ASSISTANT) {
      return;
    }

    const openAiResponse =
      await this.openAiservice.newMessageFromUserOpenAIChat(
        messages,
        username,
        nombre,
      );

    messages.push(openAiResponse);

    if (!openAiResponse.tool_calls) {
      await this.chatwootAdapter.sendMessageToChatwoot(
        conversationId,
        openAiResponse.content,
      );
      return;
    }

    for (const toolCall of openAiResponse.tool_calls) {
      const args = JSON.parse(toolCall.function.arguments);
      let toolResponse;
      switch (toolCall.function.name) {
        case FunctionsEnum.CREATE_USER:
          toolResponse = await this.createUser(
            args.full_name,
            phoneNumber,
            contactId,
            toolCall.id,
            conversationId,
          );
          break;
        case FunctionsEnum.CREATE_PAYMENT_LINK:
          toolResponse = await this.createMercadoPagoPaymentLink(
            args.name,
            args.lastName,
            args.amount,
            phoneNumber,
            username,
            toolCall.id,
          );
          break;
        case FunctionsEnum.GET_USER:
          toolResponse = await this.getUser(
            args.username,
            toolCall.id,
            conversationId,
            contactId,
          );
          break;
        case FunctionsEnum.DERIVATE_CONVERSATION:
          toolResponse = await this.agentDerivation(
            toolCall.id,
            conversationId,
            contactId,
          );
          break;
      }

      messages.push(toolResponse);
    }

    const finalResponse =
      await this.openAiservice.newMessageFromUserOpenAIChat(messages);

    await this.chatwootAdapter.sendMessageToChatwoot(
      conversationId,
      finalResponse.content,
    );

    return;
  }

  private async createUser(
    full_name: string,
    phone_number: string,
    contact_id: number,
    tool_call_id: string,
    conversationId: number,
    contact_custom_attributes?: any,
  ): Promise<any> {
    try {
      if (contact_custom_attributes) {
        if (contact_custom_attributes.ai_register_id !== '') {
          const user = await this.userService.getUserByAiRegisterId(
            contact_custom_attributes.ai_register_id,
          );
          if (!user) {
            const nombre = full_name.split(' ')[0];
            const { username, aiRegisterId, password } =
              await this.userService.registerUser(
                full_name,
                phone_number,
                tool_call_id,
                conversationId,
              );

            await this.chatwootAdapter.contactUpdate(
              contact_id,
              aiRegisterId,
              username,
              nombre,
            );

            return {
              role: 'tool' as const,
              content: [
                {
                  type: 'text' as const,
                  text: `Usuario registrado con éxito, su usuario es ${username} y su contraseña es ${password}`,
                },
              ],
              tool_call_id: tool_call_id,
            };
          }

          return {
            role: 'tool' as const,
            content: [
              {
                type: 'text' as const,
                text: `Usuario ya registrado, su usuario es ${user.username}`,
              },
            ],
            tool_call_id: tool_call_id,
          };
        }
      }
      const nombre = full_name.split(' ')[0];
      const { username, aiRegisterId, password } =
        await this.userService.registerUser(
          full_name,
          phone_number,
          tool_call_id,
          conversationId,
        );

      await this.chatwootAdapter.contactUpdate(
        contact_id,
        aiRegisterId,
        username,
        nombre,
      );

      return {
        role: 'tool' as const,
        content: [
          {
            type: 'text' as const,
            text: `Usuario registrado con éxito, su usuario es ${username} y su contraseña es ${password}`,
          },
        ],
        tool_call_id: tool_call_id,
      };
    } catch (e) {
      return {
        role: 'tool' as const,
        content: [
          {
            type: 'text' as const,
            text: `\n \"status\": \"failed\" \n \"message\": \"${e.message}\"`,
          },
        ],
        tool_call_id: tool_call_id,
      };
    }
  }

  private async createMercadoPagoPaymentLink(
    name: string,
    lastName: string,
    amount: number,
    phoneNumber: string,
    username: string,
    tool_call_id: string,
  ): Promise<any> {
    try {
      const paymentLink = await this.mercadoPagoService.createPayment({
        name,
        lastName,
        amount,
        phone: phoneNumber,
        username,
      });

      return {
        role: 'tool' as const,
        content: [
          {
            type: 'text' as const,
            text: `\n \"status\": \"success\" \n \"message\": \"Se ha creado el link de pago\", \n \"payment_link\": ${paymentLink.paymentLink}`,
          },
        ],
        tool_call_id: tool_call_id,
      };
    } catch (e) {
      return {
        role: 'tool' as const,
        content: [
          {
            type: 'text' as const,
            text: `\n \"status\": \"failed\" \n \"message\": \"Error al crear el link de pago: ${e.message}\"`,
          },
        ],
        tool_call_id: tool_call_id,
      };
    }
  }

  private async getUser(
    username: string,
    tool_call_id: string,
    conversationId: number,
    contact_id: number,
  ): Promise<any> {
    const user = await this.userService.getUserByUsername(username);
    if (!user) {
      const userDigitain = await this.digitainService.getUser(username);
      if (!userDigitain) {
        return {
          role: 'tool' as const,
          content: [
            {
              type: 'text' as const,
              text: `\n \"status\": \"failed\" \n \"message\": \"Usuario no encontrado\"`,
            },
          ],
          tool_call_id: tool_call_id,
        };
      }
      await this.userService.registerUserFromDigitain(
        userDigitain,
        conversationId,
        tool_call_id,
      );
      return {
        role: 'tool' as const,
        content: [
          {
            type: 'text' as const,
            text: `\n \"status\": \"success\" \n \"message\": \"Usuario ${username} encontrado con éxito\"`,
          },
        ],
        tool_call_id: tool_call_id,
      };
    }
    const userUpdated = await this.userService.update(user.id, {
      aiRegisterId: tool_call_id,
      conversationId: conversationId,
    });

    const nombre = userUpdated.name.split(' ')[0];

    await this.chatwootAdapter.contactUpdate(
      contact_id,
      tool_call_id,
      username,
      nombre,
    );

    return {
      role: 'tool' as const,
      content: [
        {
          type: 'text' as const,
          text: `\n \"status\": \"success\" \n \"message\": \"Usuario ${username} encontrado con éxito\"`,
        },
      ],
      tool_call_id: tool_call_id,
    };
  }

  async agentDerivation(
    tool_call_id: string,
    conversationId: number,
    contactId: number,
  ): Promise<any> {
    try {
      const agentDerivationResponse =
        await this.chatwootAdapter.derivateConversation(conversationId);

      await this.chatwootAdapter.updateSupprtCustomAttribute(contactId, true);
      return {
        role: 'tool' as const,
        content: [
          {
            type: 'text' as const,
            text: `\n \"status\": \"success\" \n \"message\": \"Se ha derivado la conversación al agente ${agentDerivationResponse.name}\"`,
          },
        ],
        tool_call_id: tool_call_id,
      };
    } catch (e) {
      return {
        role: 'tool' as const,
        content: [
          {
            type: 'text' as const,
            text: `\n \"status\": \"failed\" \n \"message\": \"Error al derivar la conversación: ${e.message}\"`,
          },
        ],
        tool_call_id: tool_call_id,
      };
    }
  }

  async sendPaymentRejectedMessage(conversationId: number, username: string) {
    const message = `Lo sentimos ${username}, el pago se ha rechazado, por favor intente nuevamente.`;

    return this.chatwootAdapter.sendMessageToChatwoot(conversationId, message);
  }

  async sendPaymentPendingMessage(conversationId: number, username: string) {
    const message = `Estimado ${username}, el pago se encuentra pendiente, por favor intente nuevamente.`;

    return this.chatwootAdapter.sendMessageToChatwoot(conversationId, message);
  }

  async sendPaymentProcessedMessage(
    conversationId: number,
    amount: number,
    username: string,
  ): Promise<any> {
    const message = `Felicidades ${username}, el pago se ha procesado con éxito!, se han cargado ${amount} fichas a tu cuenta`;

    return this.chatwootAdapter.sendMessageToChatwoot(conversationId, message);
  }
}

import { Process, Processor } from '@nestjs/bull';
import { Job } from 'bull';
import { ChatwootService } from '@/modules/chatwoot/application/service/chatwoot.service';
import { ConversationDTO } from '@/modules/chatwoot/application/dto/conversation.dto';

@Processor('message')
export class MessageProcessor {
  constructor(private readonly chatwootService: ChatwootService) {}

  @Process({
    concurrency: 10, // Procesa hasta 10 mensajes simultáneamente
  })
  async MessageProcessor(job: Job<ConversationDTO>) {
    try {
      await this.chatwootService.newMessage(job.data);
    } catch (error) {
      console.error(
        `Error processing message for conversation ${job.data.id}:`,
        error,
      );
      throw error;
    }
  }
}

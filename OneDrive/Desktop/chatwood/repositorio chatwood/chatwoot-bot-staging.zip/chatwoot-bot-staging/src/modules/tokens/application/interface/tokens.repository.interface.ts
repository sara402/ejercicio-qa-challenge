import { TokensDomain } from '../../domain/tokens.domain';
import { TokensEntity } from '../../infrastructure/persistence/entities/tokens.entity';

export const TOKENS_REPOSITORY = 'TOKENS_REPOSITORY';

export interface ITokensRepository {
  getTokensById(id: number): Promise<TokensEntity>;
  update(
    id: number,
    updatedTokenInformation: Partial<TokensDomain>,
  ): Promise<TokensEntity>;
  delete(id: number): Promise<void>;
}

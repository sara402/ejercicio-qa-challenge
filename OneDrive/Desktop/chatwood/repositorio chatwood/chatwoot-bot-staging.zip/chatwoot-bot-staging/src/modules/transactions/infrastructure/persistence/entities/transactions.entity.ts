import { Base } from '@/common/infrastructure/entities/base.entity';
import { PreferenceStatus } from '@/modules/mp/application/enum/preference-status.enum';
import { PaymentMethodsEntity } from '@/modules/payment-methods/infrastucture/persistence/entities/payment-methods.entity';
import { UserEntity } from '@/modules/user/infrastructure/persistence/entities/user.entity';
import { Column, Entity, JoinColumn, ManyToOne } from 'typeorm';

@Entity({ name: 'transactions' })
export class TransactionsEntity extends Base {
  @Column()
  userId: number;

  @Column()
  amount: number;

  @Column()
  status: PreferenceStatus;

  @ManyToOne(
    () => PaymentMethodsEntity,
    (paymentMethod) => paymentMethod.transactions,
  )
  @JoinColumn({ name: 'id_payment_method' })
  paymentMethod: PaymentMethodsEntity;

  @ManyToOne(() => UserEntity, (user) => user.transactions)
  user: UserEntity;
}

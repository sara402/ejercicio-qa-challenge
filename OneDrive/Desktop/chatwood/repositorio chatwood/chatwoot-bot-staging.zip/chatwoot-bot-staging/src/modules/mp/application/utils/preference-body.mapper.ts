import { PreferenceCreateData } from 'mercadopago/dist/clients/preference/create/types';
import { v4 as uuid } from 'uuid';
import { CreatePaymentDto } from '../dto/create-payment.dto';

export function preferenceBodyMapper(
  data: CreatePaymentDto,
): PreferenceCreateData {
  const phone = data.phone;
  const fechaActual = new Date();
  const fechaConSuma = new Date(fechaActual.getTime() + 10 * 60000);
  const itemSelected = {
    id: uuid(),
    title: `Ecommerce`,
    quantity: 1,
    unit_price: data.amount,
  };
  return {
    body: {
      items: [itemSelected],
      payer: {
        name: data.name,
        surname: data.lastName,
        phone: {
          number: phone,
        },
        date_created: new Date().toISOString(),
      },
      payment_methods: {
        excluded_payment_methods: [],
        excluded_payment_types: [],
        installments: 1,
      },
      back_urls: {
        success: `${process.env.RETURN_URL}`,
        failure: `${process.env.RETURN_URL}`,
        pending: `${process.env.RETURN_URL}`,
      },
      auto_return: 'approved',
      notification_url: `${process.env.NOTIFICATION_URL}/queue/mp-notification`,
      external_reference: uuid(),
      expiration_date_from: new Date().toISOString(),
      expiration_date_to: fechaConSuma.toISOString(),
      expires: true,
    },
  };
}

import { PaymentMethodsDomain } from '../../domain/payment-methods.domain';
import { PaymentMethodsEntity } from '../../infrastucture/persistence/entities/payment-methods.entity';

export const PAYMENT_METHODS_REPOSITORY = 'PAYMENT_METHODS_REPOSITORY';

export interface IPaymentMethodsRepository {
  findAll(): Promise<PaymentMethodsEntity[]>;
  findById(id: number): Promise<PaymentMethodsEntity>;
  create(paymentMethods: PaymentMethodsDomain): Promise<PaymentMethodsEntity>;
  update(
    id: number,
    paymentMethods: PaymentMethodsDomain,
  ): Promise<PaymentMethodsEntity>;
  delete(id: number): Promise<void>;
}

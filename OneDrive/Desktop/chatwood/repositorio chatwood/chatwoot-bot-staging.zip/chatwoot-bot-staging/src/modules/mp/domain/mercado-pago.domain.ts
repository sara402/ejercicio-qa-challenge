import { Base } from '@/common/domain/base.domain';

export class MercadoPagoDomain extends Base {
  idPaymentMethod: number;
  preferenceId: string;
  externalReference: string;
  status: string;
}

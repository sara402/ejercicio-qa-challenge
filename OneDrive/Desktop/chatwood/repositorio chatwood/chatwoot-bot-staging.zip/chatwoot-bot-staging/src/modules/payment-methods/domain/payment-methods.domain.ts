import { Base } from '@/common/domain/base.domain';
import { PaymentMethod } from '@/modules/payment-methods/application/enum/payment-method.enum';

export class PaymentMethodsDomain extends Base {
  type: PaymentMethod;
}

import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import OpenAI from 'openai';
import { ChatCompletion } from 'openai/resources';

@Injectable()
export class OpenAiAdapter {
  private OPENAI_API_KEY: string;
  constructor(private readonly environmentConfig: ConfigService) {
    this.OPENAI_API_KEY = this.environmentConfig.get('openai.apiKey');
  }

  async newConversation(
    conversation: OpenAI.Chat.Completions.ChatCompletionCreateParamsNonStreaming,
  ): Promise<ChatCompletion> {
    if (!this.OPENAI_API_KEY) {
      throw new Error('OPENAI_API_KEY is not defined in environment variables');
    }

    const openAiClient = new OpenAI({
      apiKey: this.OPENAI_API_KEY,
    });

    try {
      const response = await openAiClient.chat.completions.create(conversation);

      return response;
    } catch (error) {
      console.error('Error in OpenAI Chat API:', error);
      if (error instanceof Error) {
        throw new Error(
          `Failed to generate OpenAI Chat completion: ${error.message}`,
        );
      }
      throw new Error(
        'Failed to generate OpenAI Chat completion: Unknown error',
      );
    }
  }
}

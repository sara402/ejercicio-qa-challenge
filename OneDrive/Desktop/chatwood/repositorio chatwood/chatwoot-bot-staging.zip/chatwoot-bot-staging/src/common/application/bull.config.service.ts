import {
  BullModuleOptions,
  SharedBullConfigurationFactory,
} from '@nestjs/bull';
import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
@Injectable()
export class BullConfigService implements SharedBullConfigurationFactory {
  private readonly REDIS_HOST: string;
  private readonly REDIS_PORT: number;

  constructor(private readonly environmentConfig: ConfigService) {
    this.REDIS_HOST = this.environmentConfig.get('redis.host');
    this.REDIS_PORT = this.environmentConfig.get('redis.port');
  }
  createSharedConfiguration(): BullModuleOptions {
    const redisPort = Number(this.REDIS_PORT);
    if (isNaN(redisPort)) {
      throw new Error('REDIS_PORT must be a valid number');
    }

    return {
      redis: {
        host: this.REDIS_HOST || 'localhost',
        port: redisPort,
      },
    };
  }
}

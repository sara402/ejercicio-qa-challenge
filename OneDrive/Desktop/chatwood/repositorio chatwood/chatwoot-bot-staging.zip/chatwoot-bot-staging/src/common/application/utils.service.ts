import { Injectable } from '@nestjs/common';

@Injectable()
export class UtilsService {
  private parseKeys(request: any, convertCase: (key: string) => string): any {
    if (Array.isArray(request)) {
      return request.map((item) => this.parseKeys(item, convertCase));
    }

    if (typeof request === 'object' && request !== null) {
      const parsedRequest = {};
      for (const key in request) {
        if (request.hasOwnProperty(key)) {
          const newKey = convertCase(key);
          parsedRequest[newKey] = this.parseKeys(request[key], convertCase);
        }
      }
      return parsedRequest;
    }

    return request;
  }

  parseKeysToCamelCase(request: any): any {
    return this.parseKeys(request, this.convertSnakeCaseToCamelCase);
  }

  parseKeysToSnakeCase(request: any): any {
    return this.parseKeys(request, this.convertCamelCaseToSnakeCase);
  }

  private convertSnakeCaseToCamelCase(key: string): string {
    return key.replace(/_([a-z])/g, (_, letter) => letter.toUpperCase());
  }

  private convertCamelCaseToSnakeCase(key: string): string {
    return key.replace(/[A-Z]/g, (match) => `_${match.toLowerCase()}`);
  }
}

import { Module } from '@nestjs/common';
import { MapperService } from './application/mapper/mapper.service';
import { UtilsService } from './application/utils.service';

@Module({
  imports: [],
  providers: [MapperService, UtilsService],
  exports: [MapperService, UtilsService],
})
export class CommonModule {}

import { Module } from '@nestjs/common';
import configuration from './configuration/environment.configuration';
import { configurationValidate } from './configuration/configuration.validate';
import { ConfigModule } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { datasourceOptions as coreApiDataSourceOptions } from './configuration/orm.configuration';
import { DataSource } from 'typeorm';
import { UserModule } from './modules/user/user.module';
import { ChatwootModule } from './modules/chatwoot/chatwoot.module';
import { OpenAiModule } from './modules/open-ai/open-ai.module';
import { TokensModule } from './modules/tokens/tokens.module';
import { TransactionsModule } from './modules/transactions/transactions.module';
import { DigitainModule } from './modules/digitain/digitain.module';
import { MercadoPagoModule } from './modules/mp/mercado-pago.module';
import { BullModule } from '@nestjs/bull';
import { BullConfigService } from './common/application/bull.config.service';
import { QueueModule } from './modules/queue/queue.module';
import { PaymentMethodsModule } from './modules/payment-methods/payment-methods.module';
@Module({
  imports: [
    ConfigModule.forRoot({
      load: [configuration],
      validationSchema: configurationValidate,
      isGlobal: true,
    }),
    TypeOrmModule.forRootAsync({
      name: process.env.DB_NAME,
      useFactory: () => ({
        ...coreApiDataSourceOptions,
        autoLoadEntities: true,
        allowJs: true,
      }),
      dataSourceFactory: async (options) => {
        return new DataSource(options).initialize();
      },
    }),
    BullModule.forRootAsync({
      useClass: BullConfigService,
    }),
    UserModule,
    ChatwootModule,
    OpenAiModule,
    TokensModule,
    TransactionsModule,
    DigitainModule,
    MercadoPagoModule,
    QueueModule,
    PaymentMethodsModule,
  ],
})
export class AppModule {}

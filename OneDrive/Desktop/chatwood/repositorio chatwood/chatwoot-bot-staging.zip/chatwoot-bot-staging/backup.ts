// function messageUpdate(req: UpdateMessageDTO): Promise<any> {
//   try {
//     const { content_attributes, conversation } = req;
//     if (!conversation?.meta?.sender || !conversation.messages?.[0]) {
//       throw new Error('Datos incompletos en la solicitud');
//     }

//     const { name, phone_number: phoneNumber } = conversation.meta.sender;
//     const { account_id: accountId, conversation_id: conversationId } =
//       conversation.messages[0];
//     const contactId = conversation.contact_inbox.contact_id;

//     if (
//       !content_attributes?.submitted_values ||
//       content_attributes.submitted_values.length === 0
//     ) {
//       return;
//     }

//     const selectedValue = content_attributes.submitted_values[0]?.title;

//     switch (selectedValue) {
//       case InputValues.QuieroRegistrarme:
//         return await this.newUserRegistration(
//           name,
//           phoneNumber,
//           accountId,
//           conversationId,
//           contactId,
//         );

//       default:
//         return;
//     }
//   } catch (e) {
//     throw new HttpException(e.message, HttpStatus.BAD_REQUEST);
//   }
// }
